//
//  Rabies.m
//  VirusVanquisher
//
//  Created by asuuser on 1/19/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//
#import "Virus.h"
#import "Virus2.h"

@implementation Virus2
//ReImplimenting this function so that it is always false when the rabies virus is tapped

-(Virus *)initWithIndex:(int)button
{
    self.type = @"Rabies";
    self.imageName = @"Rabies.png";
    self.imageNameNeg = @"Rabies_2.png";
    self.image1 = [UIImage imageNamed:@"Rabies.png"];
    pointValue = 100;
    
    self.description = @"History:\n\tRabies is a preventable viral disease of mammals most often transmitted through the bite of a rabid animal. The virus infects the central nervous system, ultimately causing disease in the brain and death. Rabies vaccination may be required if bitten by an animal.\n\nTo vanquish the Rabies virus you have to shake the phone – all Rabies displaying on the screen will be vanquished by the shake.";
    
    [super initWithIndex:button];
    return self;
}

-(BOOL)checkShakeKill
{
    if([type isEqualToString:@"Rabies"])
    {
        return true;
    }
    else
        return false;
}

-(void)switchToNeg
{
    [self setImage:[UIImage imageNamed:imageNameNeg]];
}

-(void)setBack
{
    [self setImage:[UIImage imageNamed:imageName]];
}

@end
