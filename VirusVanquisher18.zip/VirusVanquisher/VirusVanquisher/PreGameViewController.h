//
//  PreGameViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 10/16/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "NewGameViewController.h"
#import "PagingView.h"
#import <UIKit/UIKit.h>
@protocol ModalViewDelegate;

@interface PreGameViewController : UIViewController{
    id<ModalViewDelegate> delegate;
    NewGameViewController *startGame1;
    PagingView *aboutPage;

    IBOutlet UIImageView *backgroundImageView;
    IBOutlet UILabel *levelLabel;
    IBOutlet UIButton *button1, *button2, *button3;
    NSString *levelString;
    UIView *containerView;

}

@property (nonatomic, assign) id<ModalViewDelegate> delegate;
@property (nonatomic, retain) IBOutlet UIImageView *backgroundImageView;
@property (nonatomic, retain) IBOutlet UILabel *levelLabel;
@property (nonatomic, retain) IBOutlet UIButton *button1,*button2, *button3;
@property (nonatomic, retain) NSString *levelString;
-(PreGameViewController *)initWithlevelID:(int)num;

-(IBAction)startNewGame:(id)sender;
@end
