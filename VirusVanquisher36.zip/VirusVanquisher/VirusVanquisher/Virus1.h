//
//  Virus1.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 1/26/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus.h"

@interface Virus1 : Virus

-(Virus *)initWithIndex:(int)button;
-(BOOL)checkTapKill:(int) buttonTapped;

@end
