//
//  WinGameViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 11/3/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import "VirusVanquisherViewController.h"
#import "WinGameViewController.h"

@implementation WinGameViewController

@synthesize delegate;
@synthesize nextLevelViewButton;
@synthesize winText;
@synthesize mainMenuButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(IBAction)startNextLevel:(id)sender
{
    if([sender isEqual: mainMenuButton])
    {
        mainMenu = [[VirusVanquisherViewController alloc] init];
        [self presentModalViewController:mainMenu animated:NO];
    }
    else
    {
        startNextLevelControl = [[PreGameViewController alloc] initWithlevelID:2];
    
        [self presentModalViewController:startNextLevelControl animated:NO]; 
    }
}

@end
