//
//  Virus4.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 2/7/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus4.h"

@implementation Virus4

-(Virus *)initWithIndex:(int)button
{
    self.vType = @"Chicken Pox";
    self.imageName = @"Varicella.png";
    self.imageNameNeg = @"Varicella_2.png";
    self.image1 = [UIImage imageNamed:@"Varicella.png"];
    pointValue = 200;
    
    self.description = @"History:\n\tChickenpox (Varicella) is a viral infection in which a person develops extremely itchy blisters all over the body. The virus also causes shingles in adults. A person with chickenpox become contagious 1 to 2 days before their blisters appear. They remain contagious until all the blisters have crusted over. Vaccination is the best protection.\n\nTo vanquish the Varicella virus you have to move it onto another Varicella virus and they both are then vanquished.";
    
    [super initWithIndex:button];
    
    return self;
}

-(BOOL)checkMultiTouchKill
{
    if([vType isEqualToString:@"Chicken Pox"])
    {
        return true;
    }
    else
        return false;
}

-(void)switchToNeg
{
    [self setImage:[UIImage imageNamed:imageNameNeg]];
}

-(void)setBack
{
    [self setImage:[UIImage imageNamed:imageName]];
}

@end
