//
//  LevelSelectVC.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 10/19/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "LevelSelectVC.h"

@implementation LevelSelectVC
@synthesize button1, button2, button3, button4, button5, button6;
@synthesize delegate;
@synthesize backgroundImageView;
@synthesize backButton;
@synthesize selectLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
    [selectLabel release];
    [backButton release];
    [button1 release];
    [button2 release];
    [button3 release];
    [button4 release];
    [button5 release];
    [button6 release];
    [backgroundImageView release];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidAppear:(BOOL)animated
{
    [button1 setAlpha:0.0];
    [button2 setAlpha:0.0];
    [button3 setAlpha:0.0];
    [button4 setAlpha:0.0];
    [button5 setAlpha:0.0];
    [button6 setAlpha:0.0];
    [selectLabel setAlpha:0.0];
    [backButton setAlpha:0.0];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [selectLabel setAlpha:1.0];
    [backButton setAlpha:1.0];
    [backgroundImageView setAlpha:1.0];
    [button1 setAlpha:1.0];
    [button2 setAlpha:1.0];
    [button3 setAlpha:1.0];
    [button4 setAlpha:1.0];
    [button5 setAlpha:1.0];
    [button6 setAlpha:1.0];
    
    [UIView commitAnimations];
    [self adjustFont];
    
    [super viewDidAppear:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)loadLevel:(id)sender {
    if([sender isEqual:button1])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:1];
        [self presentModalViewController:startGame1 animated:NO];
    }
    else if([sender isEqual:button2])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:2];
        [self presentModalViewController:startGame1 animated:NO];
    }
    else if([sender isEqual:button3])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:3];
        [self presentModalViewController:startGame1 animated:NO];
    }
    else if([sender isEqual:button4])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:4];
        [self presentModalViewController:startGame1 animated:NO];
    }
    else if([sender isEqual:button5])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:5];
        [self presentModalViewController:startGame1 animated:NO];
    
    }
    else if([sender isEqual:button6])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:6];
        [self presentModalViewController:startGame1 animated:NO];
    }
}

-(IBAction)loadView:(id)sender
{
    if([sender isEqual:backButton])
    {
        [self performSelector:@selector(vanish) withObject:nil afterDelay:0.5];
    }
    else
        [self performSelector:@selector(loadLevel:) withObject:sender afterDelay:0.5]; 
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    if(![sender isEqual:backButton])
        [backgroundImageView setAlpha:0.0];
    
    [selectLabel setAlpha:0.0];
    [backButton setAlpha:0.0];
    [button1 setAlpha:0.0];
    [button2 setAlpha:0.0];
    [button3 setAlpha:0.0];
    [button4 setAlpha:0.0];
    [button5 setAlpha:0.0];
    [button6 setAlpha:0.0];
    
    [UIView commitAnimations];
}

-(void) vanish
{
    [self dismissModalViewControllerAnimated:NO];
}

-(IBAction)playSound
{
    CFBundleRef mainBundle = CFBundleGetMainBundle();
    CFURLRef    soundFileURL;
    soundFileURL = CFBundleCopyResourceURL(mainBundle, (CFStringRef)@"Hit_Sound1", CFSTR ("wav"), NULL); 
    UInt32 soundID;
    AudioServicesCreateSystemSoundID(soundFileURL, &soundID);
    AudioServicesPlaySystemSound(soundID);
}

- (void) adjustFont
{
    selectLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    button1.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    button2.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    button3.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    button4.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    button5.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    button6.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    backButton.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationRepeatAutoreverses:YES];
    [UIView setAnimationRepeatCount:100000];
    [UIView setAnimationDuration:1.0];
    
    backButton.titleLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    button6.titleLabel.transform = CGAffineTransformMakeScale(0.925, 0.925);
    button5.titleLabel.transform = CGAffineTransformMakeScale(0.925, 0.925);
    button4.titleLabel.transform = CGAffineTransformMakeScale(0.925, 0.925);
    button3.titleLabel.transform = CGAffineTransformMakeScale(0.925, 0.925);
    button2.titleLabel.transform = CGAffineTransformMakeScale(0.925, 0.925);
    button1.titleLabel.transform = CGAffineTransformMakeScale(0.925, 0.925);
    button1.titleLabel.transform = CGAffineTransformMakeScale(0.925, 0.925);
    selectLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    
    [UIView commitAnimations];
}

@end
