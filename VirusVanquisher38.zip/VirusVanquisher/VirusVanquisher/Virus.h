//
//  Virus.h
//  VirusVanquisher
//
//  Created by johannes alexander on 10/24/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Virus : UIImageView
{
    int pointValue;
    int buttonThatSpawnedInNum;
    NSString    *type;
    UIImage     *image1;
}

@property (nonatomic, retain) UIImage *image1;

-(Virus *)initWithImageWithButton:(UIImage *)image andIndex:(int)button;
-(Virus *)initWithIndex:(int)button;
@property(nonatomic,retain) NSString *type;
-(int)getScore;
-(int)getButtonSpawned;
-(NSString*)getType;
-(void)setButtonSpawned:(int) newButton;
-(BOOL)checkTapKill;
-(BOOL)checkShakeKill;
-(BOOL)checkDoubleTapKill;

@end
