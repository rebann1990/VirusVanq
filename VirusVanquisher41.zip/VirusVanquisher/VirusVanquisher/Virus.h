//
//  Virus.h
//  VirusVanquisher
//
//  Created by johannes alexander on 10/24/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Virus : UIImageView
{
    int pointValue;
    int buttonThatSpawnedInNum;
    
    NSString    *vType;
    NSString    *description;
    NSString    *imageName;
    NSString    *imageNameNeg;
    UIImage     *image1;
}

@property (nonatomic, retain) UIImage *image1;
@property(nonatomic, retain) NSString *vType;
@property(nonatomic, retain) NSString *description;
@property(nonatomic, retain) NSString *imageName;
@property(nonatomic, retain) NSString *imageNameNeg;

-(Virus *)initWithImageWithButton:(UIImage *)image andIndex:(int)button;
-(Virus *)initWithIndex:(int)button;

-(int)getScore;
-(int)getButtonSpawned;
-(NSString*)getVType;
-(void)setButtonSpawned:(int) newButton;
-(BOOL)checkTapKill;
-(BOOL)checkShakeKill;
-(BOOL)checkDoubleTapKill;
-(BOOL)checkMultiTouchKill;
-(void)switchToNeg;
-(void)setBack;
-(BOOL)checkChangeStateKill;

@end
