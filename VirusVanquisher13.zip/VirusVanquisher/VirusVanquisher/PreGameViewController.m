//
//  PreGameViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 10/16/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "PreGameViewController.h"
#import "PagingView.h"
#import <QuartzCore/QuartzCore.h>

@implementation PreGameViewController
@synthesize delegate;
@synthesize backgroundImageView;
@synthesize levelLabel;
@synthesize levelString;
@synthesize button1, button2, button3;

int level = -1;
-(PreGameViewController *)initWithlevelID:(int)num{
    
	self = [super initWithNibName:@"PreGameViewController" bundle:nil];
	if(self) {
        level = num;
        levelString = [NSString alloc];
        switch (num) {
            case 1:
                levelString =@"Level 1: Chicken Pox";
                break;
            case 2:
                levelString =@"Level 2";
                break;
            case 3:
                levelString =@"Level 3";
                break;
            case 4:
                levelString =@"Level 4";                
                break;
            case 5:
                levelString =@"Level 5";
                break;
            case 6:
                levelString =@"Level 6";
                break;
            default:
                break;
        }
	}
	return self;	
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    
    levelLabel.text = levelString;
    
    //If the background has an alpha != the default,
    [backgroundImageView setAlpha:1.0];
    [button1 setAlpha:0.0];
    [button2 setAlpha:0.0];
    [button3 setAlpha:0.0];
    [levelLabel setAlpha:0.0];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [backgroundImageView setAlpha:0.5];
    [button1 setAlpha:1.0];
    [button2 setAlpha:1.0];
    [button3 setAlpha:1.0];
    [levelLabel setAlpha:1.0];
    
    [UIView commitAnimations];

}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void) dealloc{
    [super dealloc];
}


-(IBAction)startNewGame:(id)sender
{
    
    //Delay the method for opening the level half a second...
    
    if([sender isEqual:button3])
        [self performSelector:@selector(startLevel) withObject:nil afterDelay:0.5]; 
    else if([sender isEqual:button1])
        [self performSelector:@selector(goToMenu) withObject:nil afterDelay:0.5];
    else if([sender isEqual:button2])
        [self performSelector:@selector(goToAbout) withObject:nil afterDelay:0.5];

    //While the UIElements fade from view...
    
    [backgroundImageView setAlpha:0.5];
    [button1 setAlpha:1.0];
    [button2 setAlpha:1.0];
    [button3 setAlpha:1.0];
    [levelLabel setAlpha:1.0];
    
    //Fading Animation
    
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
    
    [backgroundImageView setAlpha:1.0];
    [button1 setAlpha:0.0];
    [button2 setAlpha:0.0];
    [button3 setAlpha:0.0];
    [levelLabel setAlpha:0.0];
    [UIView commitAnimations];

}

-(void) goToMenu
{
    [self dismissModalViewControllerAnimated:NO];
    
}

-(void) startLevel
{
    startGame1= [[[NewGameViewController alloc] init] autorelease];
    
    [self presentModalViewController:startGame1 animated:NO];    
}

-(void) goToAbout
{
    aboutPage = [[[PagingView alloc] initWithlevel:level] autorelease];
    [self presentModalViewController:aboutPage animated:NO];
}

@end
