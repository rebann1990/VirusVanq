//
//  PreGameViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 10/16/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "PreGameViewController.h"

@implementation PreGameViewController
@synthesize delegate;
@synthesize backgroundImageView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    backgroundImageView.alpha = 0.9;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void) dealloc{
    [super dealloc];
}

-(IBAction) disappear
{
    [self dismissModalViewControllerAnimated:YES];
    
}
-(IBAction)startNewGame
{
    [backgroundImageView setAlpha:0.5];
    
	[UIView beginAnimations:@"theAnimation" context:NULL];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(yourAnimationHasFinished:finished:context:)];
	[UIView setAnimationDuration:2.0];
	[backgroundImageView setAlpha:1.0]; 
    [UIView commitAnimations];
    
    startGame1= [[[NewGameViewController alloc] init] autorelease];

    [self presentModalViewController:startGame1 animated:NO];
}

@end
