//
//  DataSource.m
//  PagingScrollView
//
//  Created by Matt Gallagher on 24/01/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "DataSource.h"
#import "SynthesizeSingleton.h"
#import "Virus1.h"
#import "Virus2.h"
#import "Virus3.h"
#import "Virus4.h"
#import "Virus5.h"
#import "Virus6.h"

@implementation DataSource

SYNTHESIZE_SINGLETON_FOR_CLASS(DataSource);

//
// init
//
// Init method for the object.
//
- (id)init
{
	self = [super init];
	if (self != nil)
	{
        virus1[0] = [[Virus1 alloc] initWithIndex:-1];
        virus1[1] = [[Virus2 alloc] initWithIndex:-1];
        virus1[2] = [[Virus3 alloc] initWithIndex:-1];
        virus1[3] = [[Virus4 alloc] initWithIndex:-1];
        virus1[4] = [[Virus5 alloc] initWithIndex:-1];
        virus1[5] = [[Virus6 alloc] initWithIndex:-1];
        
		dataPages = [[NSArray alloc] initWithObjects:
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      virus1[0].vType, 
                      @"pageName",
                      virus1[0].description, 
                      @"pageText",
                      virus1[0].imageName,
                      @"imageFile", 
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      virus1[1].vType, 
                      @"pageName",
                      virus1[1].description, 
                      @"pageText",
                      virus1[1].imageName,
                      @"imageFile", 
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      virus1[2].vType, 
                      @"pageName",
                      virus1[2].description, 
                      @"pageText",
                      virus1[2].imageName,
                      @"imageFile",                       
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      virus1[3].vType, 
                      @"pageName",
                      virus1[3].description, 
                      @"pageText",
                      virus1[3].imageName,
                      @"imageFile",                      
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      virus1[4].vType, 
                      @"pageName",
                      virus1[4].description, 
                      @"pageText",
                      virus1[4].imageName,
                      @"imageFile",                      
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      virus1[5].vType, 
                      @"pageName",
                      virus1[5].description, 
                      @"pageText",
                      virus1[5].imageName,
                      @"imageFile",                      
                      nil],
                     nil];
	}
	return self;
}

- (NSInteger)numDataPages
{
	return [dataPages count];
}

- (NSDictionary *)dataForPage:(NSInteger)pageIndex
{
	return [dataPages objectAtIndex:pageIndex];
}

@end
