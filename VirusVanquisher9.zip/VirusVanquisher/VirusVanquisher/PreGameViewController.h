//
//  PreGameViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 10/16/11.
//  Copyright 2011 EOIR. All rights reserved.
//
#import "NewGameViewController.h"
#import <UIKit/UIKit.h>
@protocol ModalViewDelegate;

@interface PreGameViewController : UIViewController{
    id<ModalViewDelegate> delegate;
    NewGameViewController *startGame1;
    IBOutlet UIImageView *backgroundImageView;
}

@property (nonatomic, assign) id<ModalViewDelegate> delegate;
@property (nonatomic, retain) IBOutlet UIImageView *backgroundImageView;
-(IBAction)disappear;
-(IBAction)startNewGame;

@end
