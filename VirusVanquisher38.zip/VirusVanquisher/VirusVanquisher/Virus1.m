//
//  Virus1.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 1/26/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus1.h"

@implementation Virus1

-(Virus *)initWithIndex:(int)button
{
    self.type = @"H1N1";
    self.image1 = [UIImage imageNamed:@"H1N1.png"];
    pointValue = 50;
    [super initWithIndex:button];
    return self;
}

-(BOOL)checkTapKill
{
    BOOL isKilled = false;
    
    isKilled = true;
    
    return isKilled;
}

@end
