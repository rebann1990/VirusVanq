//
//  VirusVanquisherViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AboutViewController.h"
#import "HighScores.h"
#import "NewGameViewController.h"
#import "PagingView.h"

@protocol ModalViewDelegate

- (void)didReceiveMessage:(NSString *)message;

@end

@interface VirusVanquisherViewController : UIViewController <ModalViewDelegate> 
{
    UIViewController *menuView;
    UIButton *newGame;
    UIButton *highScores;
    UIButton *aboutGame;
    UIButton *continueGame;
    
    //DELEGATE USES THIS:
    UILabel *myMessage;
    
    PagingView *pageView;
    AboutViewController *aboutView;
    HighScores *highView;
    NewGameViewController *startGame;
}

@property (nonatomic, retain) IBOutlet UILabel *myMessage;

@property (nonatomic, retain) IBOutlet UIViewController *menuView;
@property (nonatomic,retain) IBOutlet UIButton *newGame;
@property (nonatomic,retain) IBOutlet UIButton *highScores;
@property (nonatomic,retain) IBOutlet UIButton *aboutGame;
@property (nonatomic,retain) IBOutlet UIButton *continueGame;

-(IBAction)viewAbout;
-(IBAction)viewHighs;
-(IBAction)startNewGame;

@end
