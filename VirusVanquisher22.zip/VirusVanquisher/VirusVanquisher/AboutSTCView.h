//
//  AboutSTCView.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 11/16/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutSTCView : UIViewController
{
    UIButton    *backButton;
    UITextView  *aboutText;
    UILabel     *stcLabel;
}

@property(nonatomic, retain) IBOutlet UILabel *stcLabel;
@property(nonatomic, retain) IBOutlet UITextView *aboutText;
@property(nonatomic, retain) IBOutlet UIButton *backButton;

@end
