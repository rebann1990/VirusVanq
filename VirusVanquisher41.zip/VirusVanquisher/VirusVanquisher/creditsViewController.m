//
//  creditsViewController.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 11/18/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import "creditsViewController.h"

@implementation creditsViewController
@synthesize name4, name1, name2, name3, name5, name6, name7, nameArtist;
@synthesize titleLabel, stcLabel, devLabel, artistLabel;
@synthesize backButton;
@synthesize imageView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [backButton setAlpha:0.0];
    [name1 setAlpha:0.0];
    [name2 setAlpha:0.0];
    [name3 setAlpha:0.0];
    [name4 setAlpha:0.0];
    [name5 setAlpha:0.0];
    [name6 setAlpha:0.0];
    [name7 setAlpha:0.0];
    [artistLabel setAlpha:0.0];
    [nameArtist setAlpha:0.0];
    [titleLabel setAlpha:0.0];
    [stcLabel setAlpha:0.0];
    [devLabel setAlpha:0.0];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [nameArtist setAlpha:1.0];
    [backButton setAlpha:1.0];
    [artistLabel setAlpha:1.0];
    [name1 setAlpha:1.0];
    [name2 setAlpha:1.0];
    [name3 setAlpha:1.0];
    [name4 setAlpha:1.0];
    [name5 setAlpha:1.0];
    [name6 setAlpha:1.0];
    [name7 setAlpha:1.0];
    [titleLabel setAlpha:1.0];
    [stcLabel setAlpha:1.0];
    [devLabel setAlpha:1.0];
    [UIView commitAnimations];
    
    [self adjustFont];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)goBack
{
    [self performSelector:@selector(disappear) withObject:nil afterDelay:0.5];
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [artistLabel setAlpha:0.0];
    [nameArtist setAlpha:0.0];
    [backButton setAlpha:0.0];
    [name1 setAlpha:0.0];
    [name2 setAlpha:0.0];
    [name3 setAlpha:0.0];
    [name4 setAlpha:0.0];
    [name5 setAlpha:0.0];
    [name6 setAlpha:0.0];
    [name7 setAlpha:0.0];
    [titleLabel setAlpha:0.0];
    [stcLabel setAlpha:0.0];
    [devLabel setAlpha:0.0];
    [UIView commitAnimations];
}

-(void) disappear
{
    [self dismissModalViewControllerAnimated:NO];
}

-(void) dealloc
{
    [super dealloc];
    [titleLabel release];
    [name1 release];
    [name2 release];
    [name3 release];
    [name4 release];
    [name5 release];
    [name6 release];
    [name7 release];
    [nameArtist release];
    [artistLabel release];
    [stcLabel release];
    [devLabel release];
    [backButton release];
    [imageView release];
}

-(IBAction)playSound
{
    CFBundleRef mainBundle = CFBundleGetMainBundle();
    CFURLRef    soundFileURL;
    soundFileURL = CFBundleCopyResourceURL(mainBundle, (CFStringRef)@"Hit_Sound1", CFSTR ("wav"), NULL); 
    UInt32 soundID;
    AudioServicesCreateSystemSoundID(soundFileURL, &soundID);
    AudioServicesPlaySystemSound(soundID);
}

- (void) adjustFont
{
    titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    devLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    stcLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    backButton.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    artistLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationRepeatAutoreverses:YES];
    [UIView setAnimationRepeatCount:100000];
    [UIView setAnimationDuration:1.0];
  
    artistLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    backButton.titleLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    backButton.titleLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    stcLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    devLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    titleLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    
    [UIView commitAnimations];
}

@end
