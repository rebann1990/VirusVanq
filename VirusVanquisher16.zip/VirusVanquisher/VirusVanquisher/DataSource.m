//
//  DataSource.m
//  PagingScrollView
//
//  Created by Matt Gallagher on 24/01/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "DataSource.h"
#import "SynthesizeSingleton.h"

@implementation DataSource

SYNTHESIZE_SINGLETON_FOR_CLASS(DataSource);

//
// init
//
// Init method for the object.
//
- (id)init
{
	self = [super init];
	if (self != nil)
	{
		dataPages = [[NSArray alloc] initWithObjects:
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Smallpox", 
                      @"pageName",
                      @"History:\n\tSmallpox is caused by the variola virus that emerged thousands of years ago. There is no specific treatment for smallpox disease, and the only prevention is vaccination. Generally, direct and fairly prolonged face-to-face contact is required to spread smallpox.\n\nTo vanquish the Smallpox virus you have to tap it once.", 
                      @"pageText",
                      @"Virus1 standin.png",
                      @"imageFile",
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Rabies", 
                      @"pageName",
                      @"History:\n\tRabies is a preventable viral disease of mammals most often transmitted through the bite of a rabid animal. The virus infects the central nervous system, ultimately causing disease in the brain and death. Rabies vaccination may be required if bitten by an animal.\n\nTo vanquish the Rabies virus you have to shake the phone – all Rabies displaying on the screen will be vanquished by the shake.", 
                      @"pageText",
                      @"Virus2 standin.png",
                      @"imageFile",
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Tetanus", 
                      @"pageName",
                      @"History:\n\tTetanus (aka 'Lockjaw') is an infection caused by bacteria. When the bacteria invade the body, they produce a toxin (or poison) that causes painful muscle contractions. Tetanus is also called 'lockjaw' because it often causes a person's neck and jaw muscles to lock and can be fatal. DTaP vaccine is highly effective in preventing tetanus in young children and Tdap is recommended as a booster for 11-18 year olds.\n\nTo vanquish the Tetanus virus you have to tap it twice. The first tap will change the color of the virus, the second tap will vanquish it.", 
                      @"pageText",
                      @"Virus3 standin.png",
                      @"imageFile",                      
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Typhoid", 
                      @"pageName",
                      @"History:\n\tTyphoid fever is a life-threatening illness caused by the bacterium Salmonella Typhi. It can be prevented and can usually be treated with antibiotics. Both ill persons and carriers shed Salmonella Typhi in their feces, so typhoid fever is more common in areas of the world where handwashing is less frequent and water is likely to be contaminated with sewage. If travelling to a country where typhoid is common, you should consider being vaccinated against typhoid.\n\nTo vanquish the Typhoid fever you have to move it onto another Typhoid fever and they both are then vanquished.", 
                      @"pageText",
                      @"Virus4 standin.png",
                      @"imageFile",                      
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Bubonic Plague", 
                      @"pageName",
                      @"History:\n\tThe typical sign of the most common form of human plague is a swollen lymph gland – the swollen gland is called a 'bubo'. Bubonic plague is most commonly spread by infected rodents, rabbits, or fleas. Health authorities advise that antibiotics be given for a brief period to people who have been exposed to bubonic plague.\n\nTo vanquish the bubonic plague virus you have to tap it once when it is dormant. If you tap it when it's in a live state, then it will duplicate another plague to a random square on the screen.", 
                      @"pageText",
                      @"Virus5 standin.png",
                      @"imageFile",                      
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Diphtheria", 
                      @"pageName",
                      @"History:\n\tDiphtheria is caused by toxigenic strains of Corynebacterium diphtheria (C. diphtheria). Diphtheria causes a thick covering in the back of the throat that can lead to breathing problems, paralysis, heart failure, and even death. DTaP is the most common vaccination given to children to prevent contracting Diphtheria with Td given every 10 years as an adult.\n\nTo vanquish the Diphtheria virus you have to move three of them into a row, column or diagonal like tic-tac-toe and then all three disappear.", 
                      @"pageText",
                      @"Virus6 standin.png",
                      @"imageFile",                      
                      nil],
                     nil];
	}
	return self;
}

- (NSInteger)numDataPages
{
	return [dataPages count];
}

- (NSDictionary *)dataForPage:(NSInteger)pageIndex
{
	return [dataPages objectAtIndex:pageIndex];
}

@end
