//
//  NewGameViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 10/3/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "VirusVanquisherViewController.h"
#import "NewGameViewController.h"
#import "Virus.h"
#include <stdlib.h>


@implementation NewGameViewController
@synthesize delegate;
@synthesize button0, button1, button2, button3, button4, button5, button6, button7, button8;
@synthesize virusArray , buttonArray, timerArray, spawnedVirusArray;
@synthesize scoreText;
@synthesize firstSpawnTimer;
int numOfVirusesAdded = 0;
int numOfButtonsUsed = 0;
int arrayOfButtons[9] ={0,0,0,0,0,0,0,0,0};
int timerIndex = 0;
int totalLevelScore = 0;
int spawnedVirusIndex = 0;
int currentLevelOn = 1;
int numberOfVirusEnemiesLeft = 20;
bool isPlayingLevel = FALSE;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.button0 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button3 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button4 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button5 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button6 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button7 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button8 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
       
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated
{
    isPlayingLevel = TRUE;
    
    if(currentLevelOn == 1 || currentLevelOn == 2)
    {
        numberOfVirusEnemiesLeft = 20 + 9;
    }
    else if(currentLevelOn == 3)
    {
        numberOfVirusEnemiesLeft = 25 + 9;
    }
    else if(currentLevelOn == 4)
    {
        numberOfVirusEnemiesLeft = 30 + 9;
    }
    else if(currentLevelOn == 5)
    {
        numberOfVirusEnemiesLeft = 35 + 9;
    }
    else if(currentLevelOn == 6)
    {
        numberOfVirusEnemiesLeft = 60 + 9;
    }
    
    self.buttonArray = [NSMutableArray arrayWithCapacity:9];
    self.virusArray = [NSMutableArray arrayWithCapacity:numberOfVirusEnemiesLeft];
    self.spawnedVirusArray = [NSMutableArray arrayWithCapacity:numberOfVirusEnemiesLeft];
    self.timerArray = [NSMutableArray arrayWithCapacity:2];
    
    if(currentLevelOn ==1)
    {
        for(int i = 0; i <numberOfVirusEnemiesLeft;i++)
        {
             int randomButtonToSpawn = arc4random() % 9;
            UIImage *virus1Image = [UIImage imageNamed:@"Virus1 standin.png"];
            Virus *virus1 =[[Virus alloc]initWithImageWithButton:virus1Image andIndex:randomButtonToSpawn];
            [self.virusArray insertObject:virus1 atIndex:i]; 
        }
    }
    //here we need to add initilizating all other arrays for each level with different viruses. 
    
    [self.buttonArray insertObject:button0 atIndex:0];
    [self.buttonArray insertObject:button1 atIndex:1];
    [self.buttonArray insertObject:button2 atIndex:2];
    [self.buttonArray insertObject:button3 atIndex:3];
    [self.buttonArray insertObject:button4 atIndex:4];
    [self.buttonArray insertObject:button5 atIndex:5];
    [self.buttonArray insertObject:button6 atIndex:6];
    [self.buttonArray insertObject:button7 atIndex:7];
    [self.buttonArray insertObject:button8 atIndex:8];
    
        //Random .5 - 2 seconds
    float randomTime = (arc4random() % 2) +.5f;
    timerIndex = 0;
    numOfButtonsUsed = 0;
    numOfVirusesAdded = 0;
    totalLevelScore = 0;
    spawnedVirusIndex = 0;
    
    
    self.scoreText.text = @"0";
    
	firstSpawnTimer = [NSTimer scheduledTimerWithTimeInterval:randomTime
    target:self selector:@selector(spawnEnemy:)
    userInfo:nil repeats:YES];
    
    [super viewWillAppear:YES];

}
- (void) viewWillDisappear:(BOOL)animated
{
     if([self.timerArray count]>=1)
    {
        for(int i = 0; i < [self.timerArray count];i++)
        {
            [[timerArray objectAtIndex:i] invalidate];
            [timerArray removeObjectAtIndex:i];
        }
            
    }
    if([self.virusArray count]>=1)
    {
        for(int i = 0; i < [self.virusArray count];i++)
        {
            [virusArray removeObjectAtIndex:i];
        }
        
    }
    
    if([self.spawnedVirusArray count]>=1)
    {
        for(int i = 0; i < [self.spawnedVirusArray count];i++)
        {
            [spawnedVirusArray removeObjectAtIndex:i];
        }
    }
    isPlayingLevel = FALSE;
    firstSpawnTimer = nil;
    self.virusArray = nil;
    self.buttonArray = nil;
    self.timerArray = nil;
    
    [super viewWillDisappear:YES];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void) dealloc{
    [super dealloc];
    [button0 release];
    [button1 release];
    [button2 release];
    [button3 release];
    [button4 release];
    [button5 release];
    [button6 release];
    [button7 release];
    [button8 release];
    [buttonArray release];
    [virusArray release];
    [firstSpawnTimer release];
    [timerArray release];
    [scoreText release];
    
    
}

-(IBAction) disappear
{
    [self dismissModalViewControllerAnimated:NO];
    
}
-(IBAction)tryToKill:(id)sender
{
    //need to add for all buttons, only using button0 for now to test function. This function is trying to delete but the index keeps incrementing while its checking. this is the error.
    
    bool kill = FALSE;
    
    if([sender isEqual:button0]&&numOfButtonsUsed != 0)
     {
         for(int i = 0; i < numOfVirusesAdded;i++)
         {
            if([[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]== 0 & [self.spawnedVirusArray objectAtIndex:i]!= nil)
            {
                totalLevelScore+=[[self.spawnedVirusArray objectAtIndex:i] getScore];
                self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                [[self.spawnedVirusArray objectAtIndex:i] removeFromSuperview];
                arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]] = 0;
                [self.spawnedVirusArray removeObjectAtIndex:i];
                numOfButtonsUsed--;
                numOfVirusesAdded--;
                numberOfVirusEnemiesLeft--;
                kill = TRUE;
            }
             if(kill == TRUE)
                 break;
         }
     }
    else if([sender isEqual:button1]&&numOfButtonsUsed != 0)
        {
            for(int i = 0; i < numOfVirusesAdded;i++)
            {
                if([[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]== 1 & [self.spawnedVirusArray objectAtIndex:i]!= nil)
                {
                    totalLevelScore+=[[self.spawnedVirusArray objectAtIndex:i] getScore];
                    self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                    [[self.spawnedVirusArray objectAtIndex:i] removeFromSuperview];
                    arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]] = 0;
                    [self.spawnedVirusArray removeObjectAtIndex:i];
                    numOfButtonsUsed--;
                    numOfVirusesAdded--;
                    numberOfVirusEnemiesLeft--;
                    kill = TRUE;
                }
                if(kill == TRUE)
                    break;
            }     
        }
    else if([sender isEqual:button2]&&numOfButtonsUsed != 0)
    {
        for(int i = 0; i < numOfVirusesAdded;i++)
        {
            if([[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]== 2 & [self.spawnedVirusArray objectAtIndex:i]!= nil)
            {
                totalLevelScore+=[[self.spawnedVirusArray objectAtIndex:i] getScore];
                self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                [[self.spawnedVirusArray objectAtIndex:i] removeFromSuperview];
                arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]] = 0;
                [self.spawnedVirusArray removeObjectAtIndex:i];
                numOfButtonsUsed--;
                numOfVirusesAdded--;
                numberOfVirusEnemiesLeft--;
                kill = TRUE;
            }
            if(kill == TRUE)
                break;
        }
    }
    else if([sender isEqual:button3]&&numOfButtonsUsed != 0)
    {
        for(int i = 0; i < numOfVirusesAdded;i++)
        {
            if([[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]== 3 & [self.spawnedVirusArray objectAtIndex:i]!= nil)
            {
                totalLevelScore+=[[self.spawnedVirusArray objectAtIndex:i] getScore];
                self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                [[self.spawnedVirusArray objectAtIndex:i] removeFromSuperview];
                arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]] = 0;
                [self.spawnedVirusArray removeObjectAtIndex:i];
                numOfButtonsUsed--;
                numOfVirusesAdded--;
                numberOfVirusEnemiesLeft--;
                kill = TRUE;
            }
            if(kill == TRUE)
                break;
        }
    }
    else if([sender isEqual:button4]&&numOfButtonsUsed != 0)
    {
        for(int i = 0; i < numOfVirusesAdded;i++)
        {
            if([[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]== 4 & [self.spawnedVirusArray objectAtIndex:i]!= nil)
            {
                totalLevelScore+=[[self.spawnedVirusArray objectAtIndex:i] getScore];
                self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                [[self.spawnedVirusArray objectAtIndex:i] removeFromSuperview];
                arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]] = 0;
                [self.spawnedVirusArray removeObjectAtIndex:i];
                numOfButtonsUsed--;
                numOfVirusesAdded--;
                numberOfVirusEnemiesLeft--;
                kill = TRUE;
            }
            if(kill == TRUE)
                break;
        }
    }
    else if([sender isEqual:button5]&&numOfButtonsUsed != 0)
    {
        for(int i = 0; i < numOfVirusesAdded;i++)
        {
            if([[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]== 5 & [self.spawnedVirusArray objectAtIndex:i]!= nil)
            {
                totalLevelScore+=[[self.spawnedVirusArray objectAtIndex:i] getScore];
                self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                [[self.spawnedVirusArray objectAtIndex:i] removeFromSuperview];
                arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]] = 0;
                [self.spawnedVirusArray removeObjectAtIndex:i];
                numOfButtonsUsed--;
                numOfVirusesAdded--;
                numberOfVirusEnemiesLeft--;
                kill = TRUE;
            }
            if(kill == TRUE)
                break;
        }
    }
    else if([sender isEqual:button6]&&numOfButtonsUsed != 0)
    {
        for(int i = 0; i < numOfVirusesAdded;i++)
        {
            if([[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]== 6 & [self.spawnedVirusArray objectAtIndex:i]!= nil)
            {
                totalLevelScore+=[[self.spawnedVirusArray objectAtIndex:i] getScore];
                self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                [[self.spawnedVirusArray objectAtIndex:i] removeFromSuperview];
                arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]] = 0;
                [self.spawnedVirusArray removeObjectAtIndex:i];
                numOfButtonsUsed--;
                numOfVirusesAdded--;
                numberOfVirusEnemiesLeft--;
                kill = TRUE;
            }
            if(kill == TRUE)
                break;
        }
    }    
    else if([sender isEqual:button7]&&numOfButtonsUsed != 0)
    {
        for(int i = 0; i < numOfVirusesAdded;i++)
        {
            if([[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]== 7 & [self.spawnedVirusArray objectAtIndex:i]!= nil)
            {
                totalLevelScore+=[[self.spawnedVirusArray objectAtIndex:i] getScore];
                self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                [[self.spawnedVirusArray objectAtIndex:i] removeFromSuperview];
                arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]] = 0;
                [self.spawnedVirusArray removeObjectAtIndex:i];
                numOfButtonsUsed--;
                numOfVirusesAdded--;
                numberOfVirusEnemiesLeft--;
                kill = TRUE;
            }
            if(kill == TRUE)
                break;
        }
    }
    else if([sender isEqual:button8]&&numOfButtonsUsed != 0)
    {
        for(int i = 0; i < numOfVirusesAdded;i++)
        {
            if([[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]== 8 & [self.spawnedVirusArray objectAtIndex:i]!= nil)
            {
                totalLevelScore+=[[self.spawnedVirusArray objectAtIndex:i] getScore];
                self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                [[self.spawnedVirusArray objectAtIndex:i] removeFromSuperview];
                arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]] = 0;
                [self.spawnedVirusArray removeObjectAtIndex:i];
                numOfButtonsUsed--;
                numOfVirusesAdded--;
                numberOfVirusEnemiesLeft--;
                kill = TRUE;
            }
            if(kill == TRUE)
                break;
        }
    }
    
    [self checkWin];
}

- (void)spawnEnemy:(NSTimer *)theTimer 
{
    //if all buttons are full don't spawn an enemy.
    if(numOfButtonsUsed != 9 && isPlayingLevel == TRUE)
    {
        // Random 0 - 8
       // int randomButtonToSpawn = arc4random() % 9;
        int temp = [self.virusArray count];
        int randomVirusToPickFromArray;
        if(temp != 0)
        {
            randomVirusToPickFromArray = arc4random() % temp;
        }
        else
        {
            randomVirusToPickFromArray = 0; 
        }
        
       // NSLog(@"%d",[[self.virusArray objectAtIndex: randomVirusToPickFromArray] getButtonSpawned]);
        //if(arrayOfButtons[randomButtonToSpawnButtonToSpawn] == 1)
        if(arrayOfButtons[[[self.virusArray objectAtIndex: randomVirusToPickFromArray] getButtonSpawned]]==1)
        {
            //randomButtonToSpawn = [self findAvailableButton];
            [[self.virusArray objectAtIndex: randomVirusToPickFromArray] setButtonSpawned: [self findAvailableButton]];
        }
         //NSLog(@"%d",[[self.virusArray objectAtIndex: randomVirusToPickFromArray] getButtonSpawned]);
    
        //UIImage *virus1Image = [UIImage imageNamed:@"Virus1 standin.png"];
    
        //Virus *virus1 =[[Virus alloc]initWithImageWithButton:virus1Image andIndex:randomButtonToSpawn];
        
        [self.view addSubview:[self.virusArray objectAtIndex: randomVirusToPickFromArray]];
        arrayOfButtons[[[self.virusArray objectAtIndex: randomVirusToPickFromArray] getButtonSpawned]] = 1;
        [self.spawnedVirusArray addObject:[self.virusArray objectAtIndex: randomVirusToPickFromArray]];
        [self.virusArray removeObjectAtIndex:randomVirusToPickFromArray];
        
        numOfVirusesAdded++;
        numOfButtonsUsed++;
        
        
        //Timer Code, will create a timer and delete previous one.
        //Random 1 - 3 seconds
        float randomTime = (arc4random() % 3) +1;
        if(timerIndex ==0)
        {
        [firstSpawnTimer invalidate];
        }
        
        [timerArray addObject: [NSTimer scheduledTimerWithTimeInterval:randomTime
        target:self selector:@selector(spawnEnemy:)
        userInfo:nil repeats:YES]];
        if(timerIndex != 0)
        {
            [[timerArray objectAtIndex:timerIndex-1] invalidate];
            [timerArray removeObjectAtIndex:timerIndex-1];
        }
        timerIndex = 1;
          
    }
}
-(int)findAvailableButton
{
    
    for(int i =0; i < 9 ;i++)
    {
        if(arrayOfButtons[i] == 0)
            return i;
                    
    }
    //will return -1 if the grid is full.
    return -1;
    
}
-(void)checkWin
{
    if(numberOfVirusEnemiesLeft == 9)
    {
        currentLevelOn++;
    winGameView= [[[WinGameViewController alloc] init] autorelease];
    
    [self presentModalViewController:winGameView animated:NO]; 
    }
}
@end
