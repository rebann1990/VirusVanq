//
//  PreGameViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 10/16/11.
//  Copyright 2011 EOIR. All rights reserved.
//
#import "NewGameViewController.h"
#import <UIKit/UIKit.h>
@protocol ModalViewDelegate;

@interface PreGameViewController : UIViewController{
    id<ModalViewDelegate> delegate;
    NewGameViewController *startGame1;
}

@property (nonatomic, assign) id<ModalViewDelegate> delegate;

-(IBAction)disappear;
-(IBAction)startNewGame;

@end
