//
//  Virus6.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 2/7/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus.h"

@interface Virus6 : Virus

-(Virus *)initWithIndex:(int)button;

@end
