//
//  creditsViewController.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 11/18/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>

@interface creditsViewController : UIViewController
{
    UILabel     *titleLabel;
    UILabel     *devLabel;
    UILabel     *artistLabel;
    UILabel     *nameArtist;
    UILabel     *name1;
    UILabel     *name2;
    UILabel     *name3;
    UILabel     *name4;
    UILabel     *name5;
    UILabel     *name6;
    UILabel     *name7;
    UILabel     *stcLabel;
    UIButton    *backButton;
    UIImageView *imageView;
}

@property(nonatomic, retain) IBOutlet UILabel  *artistLabel;
@property(nonatomic, retain) IBOutlet UILabel  *nameArtist;
@property(nonatomic, retain) IBOutlet UILabel  *name1;
@property(nonatomic, retain) IBOutlet UILabel  *name2;
@property(nonatomic, retain) IBOutlet UILabel  *name3;
@property(nonatomic, retain) IBOutlet UILabel  *name4;
@property(nonatomic, retain) IBOutlet UILabel  *name5;
@property(nonatomic, retain) IBOutlet UILabel  *name6;
@property(nonatomic, retain) IBOutlet UILabel  *name7;
@property(nonatomic, retain) IBOutlet UILabel  *titleLabel;
@property(nonatomic, retain) IBOutlet UILabel  *devLabel;
@property(nonatomic, retain) IBOutlet UILabel  *stcLabel;
@property(nonatomic, retain) IBOutlet UIButton *backButton;
@property(nonatomic, retain) IBOutlet UIImageView *imageView;

-(IBAction)goBack;
-(IBAction)playSound;
-(void)adjustFont;

@end
