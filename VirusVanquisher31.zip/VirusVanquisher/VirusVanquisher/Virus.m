//
//  Virus.m
//  VirusVanquisher
//
//  Created by johannes alexander on 10/24/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "Virus.h"


@implementation Virus: UIImageView

int pointValue;
int buttonThatSpawnedInNum;

-(Virus *)initWithImageWithButton:(UIImage *)image andIndex:(int) button
{
    self = [super initWithImage:image];
    if (self) {
        // Initialization code
        //bool isSpawned = false;
        pointValue = 50;
        buttonThatSpawnedInNum = button;
        
        if(button == 0)
        {
            self.frame = CGRectMake(48, 130, 73, 73);
        }
        else if(button == 1)
        {
            self.frame = CGRectMake(124, 130, 73, 73);
        }
        else if(button == 2)
        {
            self.frame = CGRectMake(201, 130, 73, 73);
        }
        else if(button == 3)
        {
            self.frame = CGRectMake(48, 205, 73, 73);
        }
        else if(button == 4)
        {
            self.frame = CGRectMake(124, 205, 73, 73);
        }
        else if(button == 5)
        {
            self.frame = CGRectMake(201, 205, 73, 73);
        }
        else if(button == 6)
        {
            self.frame = CGRectMake(48, 280, 73, 73);
        }
        else if(button == 7)
        {
            self.frame = CGRectMake(124, 280, 73, 73);
        }
        else if(button == 8)
        {
            self.frame = CGRectMake(201, 280, 73, 73);
        }
    }
    return self;
}
-(int)getScore
{
    return pointValue;
}
-(int)getButtonSpawned
{
    return buttonThatSpawnedInNum;
}
-(void)setButtonSpawned:(int) newButton
{
    buttonThatSpawnedInNum = newButton;
    if(buttonThatSpawnedInNum == 0)
    {
        self.frame = CGRectMake(48, 130, 73, 73);
    }
    else if(buttonThatSpawnedInNum == 1)
    {
        self.frame = CGRectMake(124, 130, 73, 73);
    }
    else if(buttonThatSpawnedInNum == 2)
    {
        self.frame = CGRectMake(201, 130, 73, 73);
    }
    else if(buttonThatSpawnedInNum == 3)
    {
        self.frame = CGRectMake(48, 205, 73, 73);
    }
    else if(buttonThatSpawnedInNum == 4)
    {
        self.frame = CGRectMake(124, 205, 73, 73);
    }
    else if(buttonThatSpawnedInNum == 5)
    {
        self.frame = CGRectMake(201, 205, 73, 73);
    }
    else if(buttonThatSpawnedInNum == 6)
    {
        self.frame = CGRectMake(48, 280, 73, 73);
    }
    else if(buttonThatSpawnedInNum == 7)
    {
        self.frame = CGRectMake(124, 280, 73, 73);
    }
    else if(buttonThatSpawnedInNum == 8)
    {
        self.frame = CGRectMake(201, 280, 73, 73);
    }
}
-(BOOL)checkTapKill:(int) buttonTapped
{
    BOOL isKilled = false;
    if (buttonTapped == buttonThatSpawnedInNum)
    {
        isKilled = true;
    }
    
    return isKilled;
}



@end
