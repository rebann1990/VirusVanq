//
//  Rabies.m
//  VirusVanquisher
//
//  Created by asuuser on 1/19/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//
#import "Virus.h"
#import "Virus2.h"

@implementation Virus2
//ReImplimenting this function so that it is always false when the rabies virus is tapped

-(Virus *)initWithIndex:(int)button
{
    self.image1 = [UIImage imageNamed:@"Rabies.png"];
    self.type = @"Rabies";
    pointValue = 100;
    
    [super initWithIndex:button];
    return self;
}

/*-(BOOL)checkAccelerometer: accelerometer
{
    BOOL isKilled = false;
    if (accelerometer.x = 1) {
        isKilled = true;
    }
    return isKilled;
}*/

-(BOOL)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration {
    BOOL isKilled = false;
    if(acceleration.x > .03 || acceleration.y >.03 || acceleration.z >.03 || acceleration.x < -.02 || acceleration.y < -.02 || acceleration.z < -.02) 
    {
        isKilled = true;
    }
    return isKilled;
}

-(BOOL)checkShakeKill
{
    if([type isEqualToString:@"Rabies"])
    {
        return true;
    }
    else
        return false;
}

@end
