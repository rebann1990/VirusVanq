//
//  WinGameViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 11/3/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//
#import <UIKit/UIKit.h>
@class PreGameViewController;
@class VirusVanquisherViewController;

@protocol ModalViewDelegate;

@interface WinGameViewController : UIViewController
{
    id<ModalViewDelegate> delegate;
    PreGameViewController *startNextLevelControl;
    VirusVanquisherViewController *mainMenu;
    IBOutlet UIButton *nextLevelViewButton;
    IBOutlet UIButton *mainMenuButton;
    IBOutlet UILabel *winText;
    
    
}
@property (nonatomic, assign) id<ModalViewDelegate> delegate;
@property (nonatomic,retain) IBOutlet UIButton *nextLevelViewButton;
@property (nonatomic, retain) IBOutlet UIButton *mainMenuButton;
@property (nonatomic,retain) IBOutlet UILabel *winText;

-(IBAction)startNextLevel:(id)sender;

@end
