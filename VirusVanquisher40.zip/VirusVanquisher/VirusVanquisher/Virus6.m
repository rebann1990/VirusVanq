//
//  Virus6.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 2/7/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus6.h"

@implementation Virus6

-(Virus *)initWithIndex:(int)button
{
    self.type = @"Smallpox";
    self.imageName = @"Smallpox.png";
    self.imageNameNeg = @"Smallpox_2.png";
    self.image1 = [UIImage imageNamed:@"Smallpox.png"];
    pointValue = 150;
    
    self.description = @"History:\n\tSmallpox is caused by the variola virus that emerged thousands of years ago. Generally, direct and fairly prolonged face-to-face contact is required to spread smallpox. There is no specific treatment for smallpox disease, and the only prevention is vaccination.\n\nTo vanquish the Smallpox virus you have to move three of them into a row, column or diagonal like tic-tac-toe and then all three disappear.";
    
    [super initWithIndex:button];
    return self;
}

-(void)switchToNeg
{
    [self setImage:[UIImage imageNamed:imageNameNeg]];
}

-(void)setBack
{
    [self setImage:[UIImage imageNamed:imageName]];
}

@end
