//
//  LevelSelectVC.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 10/19/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import "PreGameViewController.h"
@protocol ModalViewDelegate;

@interface LevelSelectVC : UIViewController {
    
    id<ModalViewDelegate> delegate;
    
    PreGameViewController   *startGame1;
    UIButton                *button1;
    UIButton                *button2;
    UIButton                *button3;
    UIButton                *button4;
    UIButton                *button5;
    UIButton                *button6;
    UIImageView             *backgroundImageView;
    UILabel                 *selectLabel;
    UIButton                *backButton;
}

@property (nonatomic, retain) id<ModalViewDelegate> delegate;

@property (nonatomic, retain) IBOutlet UIButton     *button1;
@property (nonatomic, retain) IBOutlet UIButton     *button2;
@property (nonatomic, retain) IBOutlet UIButton     *button3;
@property (nonatomic, retain) IBOutlet UIButton     *button4;
@property (nonatomic, retain) IBOutlet UIButton     *button5;
@property (nonatomic, retain) IBOutlet UIButton     *button6;
@property (nonatomic, retain) IBOutlet UIImageView  *backgroundImageView;
@property (nonatomic, retain) IBOutlet UIButton     *backButton;
@property (nonatomic, retain) IBOutlet UILabel      *selectLabel;

- (void)loadLevel:(id)sender;
- (IBAction)loadView:(id)sender;
- (IBAction)playSound;
- (void)adjustFont;

@end
