//
//  NewGameViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 10/3/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ModalViewDelegate;

@interface NewGameViewController : UIViewController {
    id<ModalViewDelegate> delegate;
}
@property (nonatomic, assign) id<ModalViewDelegate> delegate;



@end
