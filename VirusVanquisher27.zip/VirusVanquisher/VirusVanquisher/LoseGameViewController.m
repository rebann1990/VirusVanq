//
//  LoseGameViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 11/14/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import "LoseGameViewController.h"
#import "VirusVanquisherViewController.h"

@implementation LoseGameViewController

@synthesize delegate;
@synthesize loseText;
@synthesize mainMenuButton, retryButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void) dealloc
{
    [super dealloc];
    [retryButton release];
    [mainMenuButton release];
    [loseText release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)retryLevel:(id)sender
{
    //both mainMenu and retryLevel buttons use this method. Using senders to differentiate them.
    if([sender isEqual: mainMenuButton])
    {
        mainMenu = [[VirusVanquisherViewController alloc] init];
        [self presentModalViewController:mainMenu animated:NO];
    }
    else
    {
        retryLevelControl = [[PreGameViewController alloc] initWithlevelID:1];
        //this needs to be for any level to retry not just level 1.
        
        [self presentModalViewController:retryLevelControl animated:NO]; 
    }
}

@end
