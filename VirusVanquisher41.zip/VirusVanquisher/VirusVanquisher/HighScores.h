//
//  HighScores.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 10/3/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>

@protocol ModalViewDelegate;


@interface HighScores : UIViewController 
{
    id<ModalViewDelegate>   delegate;
    
    UIImageView             *backgroundImageView;
    UISegmentedControl      *levelSegment;
    UITextView              *highScoreTV;
    UIButton                *mainMenuButton;
    UILabel                 *hsLabel;
}

@property (nonatomic, retain) id<ModalViewDelegate> delegate;

@property (nonatomic, retain) IBOutlet UISegmentedControl *levelSegment;
@property (nonatomic, retain) IBOutlet UIButton *mainMenuButton;
@property (nonatomic, retain) IBOutlet UITextView *highScoreTV;
@property (nonatomic, retain) IBOutlet UILabel *hsLabel;

-(IBAction)showScores;
-(IBAction)disappear;
-(IBAction)playSound;
@end
