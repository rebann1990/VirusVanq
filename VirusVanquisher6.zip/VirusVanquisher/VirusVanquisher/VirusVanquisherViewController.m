//
//  VirusVanquisherViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "VirusVanquisherViewController.h"
#import "AboutViewController.h"
#import "HighScores.h"
#import "NewGameViewController.h"

@implementation VirusVanquisherViewController

@synthesize menuView;
@synthesize newGame;
@synthesize highScores;
@synthesize aboutGame;
@synthesize continueGame;

//DELEGATE USES THIS:
@synthesize myMessage;

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    UIImage *background = [UIImage imageNamed: @"MenuBackground.png"];    
    UIImageView *imageView = [[UIImageView alloc] initWithImage: background]; 
    imageView.alpha = 0.5;
    [self.view addSubview: imageView]; 
    [self.view sendSubviewToBack:imageView];
    [imageView release];
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//DELEGATE USES THIS
- (void)didReceiveMessage:(NSString *)message {
	[myMessage setText:message];
}

-(IBAction)viewAbout
{
	pageView = [[[PagingView alloc] init] autorelease];
    pageView.delegate = self;
    [self presentModalViewController:pageView animated:YES];    
}

-(IBAction)viewHighs
{
	highView = [[[HighScores alloc] init] autorelease];
    highView.delegate = self;
    [self presentModalViewController:highView animated:YES];     
}

- (void) dealloc {
    [super dealloc];
}
- (IBAction)startNewGame
{
    startGame= [[[NewGameViewController alloc] init] autorelease];
    startGame.delegate = self;
    [self presentModalViewController:startGame animated:YES];
}


@end
