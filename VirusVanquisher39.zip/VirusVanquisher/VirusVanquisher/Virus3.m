//
//  Virus3.m
//  VirusVanquisher
//
//  Created by johannes alexander on 2/1/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus3.h"

@implementation Virus3
//
//  Virus1.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 1/26/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//
-(Virus *)initWithIndex:(int)button
{
    counterTilDeath = 2;
    self.type = @"Hepatitis B";
    self.imageName = @"Hepatitis.png";
    self.image1 = [UIImage imageNamed:@"Hepatitis.png"];
    pointValue = 150;
    
    self.description = @"History:\n\tHepatitis B causes inflammation of the liver. Infection can be spread through contact with an infected person via direct contact with blood/body fluids, shared needles or shared personal items (such as toothbrushes, razors, and nail clippers). People with chronic hepatitis may have no symptoms, even though gradual liver damage may be occurring. Treatments vary after getting HepB but prevention via the HepB vaccination is the best protection.\n\nTo vanquish the Hepatitis B virus you have to tap it twice. The first tap will change its color and the second tap will vanquish it.";
    
    [super initWithIndex:button];
    return self;
}

-(BOOL)checkDoubleTapKill
{
    BOOL isKilled = false;
    if(counterTilDeath == 2)
    {
        counterTilDeath--;
        return false;
    }
    else if(counterTilDeath == 1)
    {
        isKilled = true;
    }
    
    return isKilled;
}

@end
