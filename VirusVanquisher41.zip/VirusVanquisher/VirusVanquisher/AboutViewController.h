//
//  AboutViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "PagingView.h"
#import "AboutSTCView.h"
#import "creditsViewController.h"
#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
@protocol ModalViewDelegate;

@interface AboutViewController : UIViewController
{
    id<ModalViewDelegate>   delegate;
    
    UIButton                *mainMenuButton;
    UIButton                *aboutSTCButton;
    UIButton                *virusInfoButton;
    UIButton                *creditsButton;
    UIImageView             *backgroundImageView;
    UILabel                 *aboutLabel;
    
    PagingView              *virusInfoView;
    AboutSTCView            *companyView;
    creditsViewController   *creditsView;
}

@property (nonatomic, assign) id<ModalViewDelegate> delegate;
@property (nonatomic, retain) IBOutlet UIButton *mainMenuButton;
@property (nonatomic, retain) IBOutlet UIButton *aboutSTCButton;
@property (nonatomic, retain) IBOutlet UIButton *virusInfoButton;
@property (nonatomic, retain) IBOutlet UIButton *creditsButton;
@property (nonatomic, retain) IBOutlet UILabel  *aboutLabel;
@property (nonatomic, retain) IBOutlet UIImageView *backgroundImageView;

-(IBAction)didPressButton:(id)sender;
-(void)disappear;
-(IBAction)playSound;
-(void)adjustFont;

@end
