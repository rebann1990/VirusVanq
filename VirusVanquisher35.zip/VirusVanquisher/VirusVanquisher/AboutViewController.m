//
//  AboutViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "AboutViewController.h"
#import "VirusVanquisherViewController.h"

@implementation AboutViewController
@synthesize delegate;
@synthesize mainMenuButton, aboutSTCButton, virusInfoButton, creditsButton, backgroundImageView, aboutLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [mainMenuButton setAlpha:0.0];
    [aboutSTCButton setAlpha:0.0];
    [virusInfoButton setAlpha:0.0];
    [creditsButton setAlpha:0.0];
    [aboutLabel setAlpha:0.0];
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [aboutLabel setAlpha:1.0];
    [mainMenuButton setAlpha:1.0];
    [aboutSTCButton setAlpha:1.0];
    [virusInfoButton setAlpha:1.0];
    [creditsButton setAlpha:1.0];
    
    [UIView commitAnimations];
    
    [self adjustFont];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    self = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)didPressButton:(id)sender
{
    if([sender isEqual:mainMenuButton])
    {
        [self performSelector:@selector(disappear) withObject:nil afterDelay:0.5]; 
    }
    else if([sender isEqual:aboutSTCButton])
    {
        [self performSelector:@selector(loadCompany) withObject:nil afterDelay:0.5]; 
    }
    else if([sender isEqual:virusInfoButton])
    {
        [self performSelector:@selector(loadViruses) withObject:nil afterDelay:0.5]; 
    }
    else if([sender isEqual:creditsButton])
    {
        [self performSelector:@selector(loadCredits) withObject:nil afterDelay:0.5]; 
    }
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    [aboutLabel setAlpha:0.0];
    [mainMenuButton setAlpha:0.0];
    [aboutSTCButton setAlpha:0.0];
    [virusInfoButton setAlpha:0.0];
    [creditsButton setAlpha:0.0];
    [UIView commitAnimations];
}

-(void) loadCompany
{
     companyView = [[[AboutSTCView alloc] init] autorelease];
     [self presentModalViewController:companyView animated:NO];
}

-(void) loadViruses
{
    //This loads the virus information page
    virusInfoView = [[[PagingView alloc] init] autorelease];
    [self presentModalViewController:virusInfoView animated:NO];
}

-(void) loadCredits
{
    creditsView = [[[creditsViewController alloc] init] autorelease];
    [self presentModalViewController:creditsView animated:NO];
}

-(void) disappear
{
    [self dismissModalViewControllerAnimated:NO];

}

-(void) dealloc
{
    [super dealloc];
    [mainMenuButton release];
    [aboutSTCButton release];
    [virusInfoButton release];
    [creditsButton release];
    [backgroundImageView release];
    [aboutLabel release];
}

-(IBAction)playSound
{
    CFBundleRef mainBundle = CFBundleGetMainBundle();
    CFURLRef    soundFileURL;
    soundFileURL = CFBundleCopyResourceURL(mainBundle, (CFStringRef)@"Hit_Sound1", CFSTR ("wav"), NULL); 
    UInt32 soundID;
    AudioServicesCreateSystemSoundID(soundFileURL, &soundID);
    AudioServicesPlaySystemSound(soundID);
}

- (void) adjustFont
{
    aboutLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    mainMenuButton.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    aboutSTCButton.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    virusInfoButton.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    creditsButton.titleLabel.transform = CGAffineTransformMakeScale(1.0, 1.0);
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationRepeatAutoreverses:YES];
    [UIView setAnimationRepeatCount:100000];
    [UIView setAnimationDuration:1.0];
    
    creditsButton.titleLabel.transform = CGAffineTransformMakeScale(0.925, 0.925);
    virusInfoButton.titleLabel.transform = CGAffineTransformMakeScale(0.925, 0.925);
    aboutSTCButton.titleLabel.transform = CGAffineTransformMakeScale(0.925, 0.925);
    mainMenuButton.titleLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    mainMenuButton.titleLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    aboutLabel.transform = CGAffineTransformMakeScale(0.96, 0.96);
    
    [UIView commitAnimations];
}

@end
