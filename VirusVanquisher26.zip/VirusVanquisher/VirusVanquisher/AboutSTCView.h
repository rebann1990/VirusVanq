//
//  AboutSTCView.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 11/16/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "STCInfoView.h"

@interface AboutSTCView : UIViewController <UIScrollViewDelegate>
{
    UIButton        *backButton;
    UILabel         *stcLabel;
    UIScrollView    *scrollView;
    UIPageControl   *pageControl;
    NSMutableArray  *viewControllers;
    BOOL            pageControlUsed;
}

@property(nonatomic, retain) IBOutlet UILabel *stcLabel;
@property(nonatomic, retain) IBOutlet UIButton *backButton;

@property(nonatomic, retain) IBOutlet UIScrollView *scrollView;
@property(nonatomic, retain) IBOutlet UIPageControl *pageControl;
@property (nonatomic, retain) NSMutableArray *viewControllers;

-(IBAction)changePage:(id)sender;

@end
