//
//  Rabies.h
//  VirusVanquisher
//
//  Created by asuuser on 1/19/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Virus2 : Virus

-(Virus *)initWithIndex:(int)button;
//Rabies is Inheriting Virus's Point Value and buttonThatSpawnedInNum 
-(BOOL)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration;
-(BOOL)checkShakeKill;

@end
