//
//  NewGameViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 10/3/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import <Foundation/Foundation.h>
#import "WinGameViewController.h"
#import "LoseGameViewController.h"
#import "PagingView.h"
@protocol ModalViewDelegate;

@interface NewGameViewController : UIViewController 
{
    id<ModalViewDelegate>   delegate;
    UIButton                *button0;
    UIButton                *button1;
    UIButton                *button2;
    UIButton                *button3;
    UIButton                *button4;
    UIButton                *button5;
    UIButton                *button6;
    UIButton                *button7;
    UIButton                *button8;
    
    UILabel                 *enemiesLeftNumText;
    UILabel                 *scoreText;
    
    WinGameViewController   *winGameView;
    LoseGameViewController  *loseGameView;
    PagingView              *aboutPage;
    
    UIView                  *pauseView;
    UIButton                *resumeButton;
    UIButton                *howToButton;
    UIButton                *quitButton;
    UIButton                *pauseButton;
    UILabel                 *levelNum;
    
    //This should be a UIImageView with the words outbreak written instead of a UILabel, this is temporary for now.
    UILabel                 *outbreakText;
    
    
    NSMutableArray          *buttonArray;
    NSMutableArray          *virusArray;
    NSMutableArray          *timerArray;
    NSMutableArray          *spawnedVirusArray;    
    NSTimer                 *firstSpawnTimer;
    
    
}
@property (nonatomic, assign) id<ModalViewDelegate> delegate;

@property (nonatomic, retain) IBOutlet UIButton *resumeButton;
@property (nonatomic, retain) IBOutlet UIButton *howToButton;
@property (nonatomic, retain) IBOutlet UIButton *quitButton;
@property (nonatomic, retain) IBOutlet UIView *pauseView;
@property (nonatomic, retain) IBOutlet UILabel *levelNum;
@property (nonatomic, retain) IBOutlet UILabel *enemiesLeftNumText;

@property (nonatomic, retain) IBOutlet UIButton *button0;
@property (nonatomic, retain) IBOutlet UIButton *button1;
@property (nonatomic, retain) IBOutlet UIButton *button2;
@property (nonatomic, retain) IBOutlet UIButton *button3;
@property (nonatomic, retain) IBOutlet UIButton *button4;
@property (nonatomic, retain) IBOutlet UIButton *button5;
@property (nonatomic, retain) IBOutlet UIButton *button6;
@property (nonatomic, retain) IBOutlet UIButton *button7;
@property (nonatomic, retain) IBOutlet UIButton *button8;
@property (nonatomic, retain) IBOutlet UIButton *pauseButton;
@property (nonatomic, retain) IBOutlet UILabel *scoreText;
//delete this later for UIImageView
;
@property (nonatomic, retain) IBOutlet UILabel *outbreakText;
@property(nonatomic, retain) NSMutableArray *buttonArray;
@property(nonatomic, retain) NSMutableArray *virusArray;
@property(nonatomic, retain) NSMutableArray *timerArray;
@property(nonatomic, retain) NSMutableArray *spawnedVirusArray;

@property(nonatomic, retain) NSTimer *firstSpawnTimer;


-(NewGameViewController *)initWithlevelID:(int)num;

-(IBAction)quitGame;
-(IBAction)pauseGame;
-(IBAction)disappear;
-(IBAction)tryToKill:(id)sender;
-(IBAction)playSound;
-(void)spawnEnemy:(NSTimer *)theTimer;
-(void)hideOutbreakText:(NSTimer *)theTimer;
-(int)findAvailableButton;
-(void)checkWin;
-(void)checkLose;
-(void)calculateHitMultiplier:(BOOL)wasKilled;

@end
