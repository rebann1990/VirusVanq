//
//  PageView2.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 10/17/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PageView2 : UIViewController {
    NSInteger pageIndex;
    BOOL textViewNeedsUpdate;
    IBOutlet UILabel *label;
    IBOutlet UITextView *textView;
}

@property NSInteger pageIndex;
@property (nonatomic, retain) IBOutlet UILabel *label;
@property (nonatomic, retain) IBOutlet UITextView *textView;

- (void)updateTextViews:(BOOL)force;
@end