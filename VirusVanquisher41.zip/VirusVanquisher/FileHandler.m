#import "FileHandler.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

NSString* const SAVE_PATH = @"";
NSString* const SCORE_DIR = @"";
NSString* const SCORE_DELIMITER = @",";

const int NUM_SCORES = 10;
const int DATE_LENGTH = 8;

@implementation FileHandler

+(int) SubmitScore: (int) score withFile: (NSString*) levelFile withDate: (NSString*) date
{
	NSMutableArray* scores = [[NSMutableArray alloc] initWithContentsOfFile:levelFile];
                            

	NSString* submittedEntry = [[date stringByAppendingString: SCORE_DELIMITER] stringByAppendingString: [NSString stringWithFormat:@"%d",score]];

	for(int i = 0; i < NUM_SCORES; ++i)
	{
		NSString* currentEntry = [scores objectAtIndex:i];
		NSArray* split = [currentEntry componentsSeparatedByString:SCORE_DELIMITER];
		int currentScore = [[split objectAtIndex:1] intValue];

		if(score > currentScore)
		{
			[scores insertObject:submittedEntry atIndex:i];
			[scores removeLastObject];
            NSArray *tempArray = [[NSArray arrayWithArray:scores] alloc];
			[tempArray writeToFile:levelFile atomically:TRUE]; 
            [tempArray release];
            [scores release];
			return i;
		}
	}
    
    [scores release];
    return -1;
	/*char* fileName = [ levelFile cStringUsingEncoding:ASCIIEncoding ] ;
	char* date = [ date cStringUsingEncoding:ASCIIEncoding ];
	   
	NSString* scores = [self GetScores:levelFile];
	
	char* scoresC = [scores cStringUsingEncoding:ASCIIEncoding ];
	
	char* allScores[NUM_SCORES];
	char* current = strtok(scoresC, ";");

	for(int i = 0; i < NUM_SCORES; ++i)
	{
		if(current != NULL)
		{
			int currentScore = atoi(strtok(NULL,","));
			if(
		}
	}
*/
}

+(NSMutableArray*) GetScores : (NSString*) levelFile
{
	 NSMutableArray* scores = [[NSMutableArray alloc] initWithContentsOfFile:levelFile];
    return scores;
}

+(BOOL) SaveLevel: (int) level;
{
	NSString* levelAsString = [NSString stringWithFormat:@"%d",level];
	[levelAsString writeToFile:SAVE_PATH atomically:YES];
	return YES;
}

+(int) LoadLevel
{
	NSString* levelAsString = [[NSString alloc] initWithContentsOfFile:SAVE_PATH];
	return [levelAsString intValue];
}
@end
