//
//  Virus1.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 1/26/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus1.h"

@implementation Virus1

-(Virus *)initWithIndex:(int)button
{
    self.type = @"H1N1 Influenza";
    self.imageName = @"H1N1.png";
    self.imageNameNeg = @"H1N1_2.png";
    self.image1 = [UIImage imageNamed:@"H1N1.png"];
    pointValue = 50;
   
    self.description = @"History:\n\tH1N1 Influenza (swine flu) is a respiratory disease caused by Type A influenza viruses and is similar to seasonal flu. Avoid touching your eyes, nose or mouth; germs spread this way. During flu season wash your hands often with soap and water, especially after you cough or sneeze. Vaccination is the best protection.\n\nTo vanquish the H1N1 virus you have to tap it once.";
    
    [super initWithIndex:button];
    return self;
}

-(BOOL)checkTapKill
{
    BOOL isKilled = false;
    
    isKilled = true;
    
    return isKilled;
}

-(void)switchToNeg
{
    [self setImage:[UIImage imageNamed:imageNameNeg]];
}

-(void)setBack
{
    [self setImage:[UIImage imageNamed:imageName]];
}

@end
