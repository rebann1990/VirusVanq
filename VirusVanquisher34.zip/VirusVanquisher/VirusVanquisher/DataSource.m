//
//  DataSource.m
//  PagingScrollView
//
//  Created by Matt Gallagher on 24/01/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "DataSource.h"
#import "SynthesizeSingleton.h"

@implementation DataSource

SYNTHESIZE_SINGLETON_FOR_CLASS(DataSource);

//
// init
//
// Init method for the object.
//
- (id)init
{
	self = [super init];
	if (self != nil)
	{
		dataPages = [[NSArray alloc] initWithObjects:
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Influenza (H1N1)", 
                      @"pageName",
                      @"History:\n\tH1N1 flu (swine flu) is a respiratory disease caused by Type A influenza viruses and is similar to seasonal flu. Avoid touching your eyes, nose or mouth; germs spread this way. During flu season wash your hands often with soap and water, especially after you cough or sneeze. Vaccination is the best protection.\n\nTo vanquish the H1N1 virus you have to tap it once.", 
                      @"pageText",
                      @"Virus1 standin.png",
                      @"imageFile",
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Rabies", 
                      @"pageName",
                      @"History:\n\tRabies is a preventable viral disease of mammals most often transmitted through the bite of a rabid animal. The virus infects the central nervous system, ultimately causing disease in the brain and death. Rabies vaccination may be required if bitten by an animal.\n\nTo vanquish the Rabies virus you have to shake the phone – all Rabies displaying on the screen will be vanquished by the shake.", 
                      @"pageText",
                      @"Virus2 standin.png",
                      @"imageFile",
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Hepatitis B", 
                      @"pageName",
                      @"History:\n\tHepatitis B causes inflammation of the liver. Infection can be spread through contact with an infected person via direct contact with blood/body fluids, shared needles or shared personal items (such as toothbrushes, razors, and nail clippers). People with chronic hepatitis may have no symptoms, even though gradual liver damage may be occurring. Treatments vary after getting HepB but prevention via the HepB vaccination is the best protection.\n\nTo vanquish the Hepatitis B virus you have to tap it twice. The first tap will change its color and the second tap will vanquish it.", 
                      @"pageText",
                      @"Virus3 standin.png",
                      @"imageFile",                      
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Chicken Pox (Varicella)", 
                      @"pageName",
                      @"History:\n\tChickenpox (Varicella) is a viral infection in which a person develops extremely itchy blisters all over the body. The virus also causes shingles in adults. A person with chickenpox become contagious 1 to 2 days before their blisters appear. They remain contagious until all the blisters have crusted over. Vaccination is the best protection.\n\nTo vanquish the Varicella virus you have to move it onto another Varicella virus and they both are then vanquished.", 
                      @"pageText",
                      @"Virus4 standin.png",
                      @"imageFile",                      
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: German Measles (Rubella)", 
                      @"pageName",
                      @"History:\n\tGerman Measles (Rubella) is an infection in which there is a rash on the skin. It is spread through the air or by close contact. A person with rubella is contagious from 1 week before the rash begins, until 1 - 2 weeks after the rash disappears. Vaccination (MMR) is the best protection.\n\nTo vanquish the Rubella virus you have to tap it once when it is dormant. If you tap it when it's in a live state, then it will duplicate another plague to a random square on the screen.", 
                      @"pageText",
                      @"Virus5 standin.png",
                      @"imageFile",                      
                      nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:
                      @"Enemy: Smallpox", 
                      @"pageName",
                      @"History:\n\tSmallpox is caused by the variola virus that emerged thousands of years ago. Generally, direct and fairly prolonged face-to-face contact is required to spread smallpox. There is no specific treatment for smallpox disease, and the only prevention is vaccination.\n\nTo vanquish the Smallpox virus you have to move three of them into a row, column or diagonal like tic-tac-toe and then all three disappear.", 
                      @"pageText",
                      @"Virus6 standin.png",
                      @"imageFile",                      
                      nil],
                     nil];
	}
	return self;
}

- (NSInteger)numDataPages
{
	return [dataPages count];
}

- (NSDictionary *)dataForPage:(NSInteger)pageIndex
{
	return [dataPages objectAtIndex:pageIndex];
}

@end
