//
//  AboutViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "AboutViewController.h"
#import "VirusVanquisherViewController.h"

@implementation AboutViewController
@synthesize delegate;
@synthesize mainMenuButton, aboutSTCButton, virusInfoButton, creditsButton, backgroundImageView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [mainMenuButton setAlpha:0.0];
    [aboutSTCButton setAlpha:0.0];
    [virusInfoButton setAlpha:0.0];
    [creditsButton setAlpha:0.0];
    [backgroundImageView setAlpha:1.0];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [backgroundImageView setAlpha:0.5];
    [mainMenuButton setAlpha:1.0];
    [aboutSTCButton setAlpha:1.0];
    [virusInfoButton setAlpha:1.0];
    [creditsButton setAlpha:1.0];
    
    [UIView commitAnimations];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    self = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)didPressButton:(id)sender
{
    if([sender isEqual:mainMenuButton])
    {
        [self performSelector:@selector(disappear) withObject:nil afterDelay:0.5]; 
    }
    else if([sender isEqual:aboutSTCButton])
    {
        [self performSelector:@selector(loadCompany) withObject:nil afterDelay:0.5]; 
    }
    else if([sender isEqual:virusInfoButton])
    {
        [self performSelector:@selector(loadViruses) withObject:nil afterDelay:0.5]; 
    }
    else if([sender isEqual:creditsButton])
    {
        [self performSelector:@selector(loadCredits) withObject:nil afterDelay:0.5]; 
    }
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    [backgroundImageView setAlpha:1.0];
    [mainMenuButton setAlpha:0.0];
    [aboutSTCButton setAlpha:0.0];
    [virusInfoButton setAlpha:0.0];
    [creditsButton setAlpha:0.0];
    [UIView commitAnimations];
}

-(void) loadCompany
{
     companyView = [[[AboutSTCView alloc] init] autorelease];
     [self presentModalViewController:companyView animated:NO];
}

-(void) loadViruses
{
    //This loads the virus information page
    virusInfoView = [[[PagingView alloc] init] autorelease];
    [self presentModalViewController:virusInfoView animated:NO];
}

-(void) loadCredits
{
    creditsView = [[[creditsViewController alloc] init] autorelease];
    [self presentModalViewController:creditsView animated:NO];
}

-(void) disappear
{
    [self dismissModalViewControllerAnimated:NO];

}

-(void) dealloc
{
    [super dealloc];
    [mainMenuButton release];
    [aboutSTCButton release];
    [virusInfoButton release];
    [creditsButton release];
    [backgroundImageView release];
}

@end
