//
//  HighScores.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 10/3/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "HighScores.h"
#import "VirusVanquisherViewController.h"

@implementation HighScores
@synthesize delegate;
@synthesize highScoreTV;
@synthesize levelSegment;
@synthesize mainMenuButton;
@synthesize hsLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidAppear:(BOOL)animated
{
    [hsLabel setAlpha:0.0];
    [levelSegment setAlpha:0.0];
    [highScoreTV setAlpha:0.0];
    [mainMenuButton setAlpha:0.0];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [hsLabel setAlpha: 1.0];
    [levelSegment setAlpha:1.0];
    [highScoreTV setAlpha:1.0];
    [mainMenuButton setAlpha:1.0];
    [UIView commitAnimations];
    
    NSString *tS = [levelSegment titleForSegmentAtIndex:levelSegment.selectedSegmentIndex];
    
    if([tS isEqualToString: @"1"])
        highScoreTV.text = @"Hey 1";

    [super viewDidAppear:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction) showScores
{
    NSString *tS = [levelSegment titleForSegmentAtIndex:levelSegment.selectedSegmentIndex];
    
    if([tS isEqualToString: @"1"])
        highScoreTV.text = @"Hey 1";
    else if([tS isEqualToString: @"2"])
        highScoreTV.text = @"Hey 2";    
    else if([tS isEqualToString: @"3"])
        highScoreTV.text = @"Hey 3";
    else if([tS isEqualToString: @"4"])
        highScoreTV.text = @"Hey 4";
    else if([tS isEqualToString: @"5"])
        highScoreTV.text = @"Hey 5";
    else if([tS isEqualToString: @"6"])
        highScoreTV.text = @"Hey 6";
    
}

-(IBAction) disappear
{
    [self performSelector:@selector(vanish) withObject:nil afterDelay:0.5];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [hsLabel setAlpha:0.0];
    [levelSegment setAlpha:0.0];
    [highScoreTV setAlpha:0.0];
    [mainMenuButton setAlpha:0.0];
    
    [UIView commitAnimations];
}

-(void) vanish
{
    [self dismissModalViewControllerAnimated:NO];
}

- (void)dealloc
{
    [super dealloc];
    [mainMenuButton release];
    [backgroundImageView release];
    [levelSegment release];
    [highScoreTV release];
    [hsLabel release];
}

-(IBAction)playSound
{
    CFBundleRef mainBundle = CFBundleGetMainBundle();
    CFURLRef    soundFileURL;
    soundFileURL = CFBundleCopyResourceURL(mainBundle, (CFStringRef)@"Hit_Sound1", CFSTR ("wav"), NULL); 
    UInt32 soundID;
    AudioServicesCreateSystemSoundID(soundFileURL, &soundID);
    AudioServicesPlaySystemSound(soundID);
}

@end
