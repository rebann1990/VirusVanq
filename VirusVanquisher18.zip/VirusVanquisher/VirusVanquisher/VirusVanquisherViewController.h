//
//  VirusVanquisherViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AboutViewController.h"
#import "HighScores.h"
#import "PreGameViewController.h"
#import "LevelSelectVC.h"
#import "PagingView.h"

@protocol ModalViewDelegate

- (void)didReceiveMessage:(NSString *)message;

@end

@interface VirusVanquisherViewController : UIViewController <ModalViewDelegate> 
{
    UIImageView *backgroundImageView;
    UIViewController *menuView;
    UIButton *newGame1;
    UIButton *highScores;
    UIButton *aboutGame;
    UIButton *continueGame;
    UIButton *quickPlay;
    
    //DELEGATE USES THIS:
    UILabel *myMessage;
    UILabel *gameLabel;
    
    AboutViewController *aboutView;
    HighScores *highView;
    PreGameViewController *startGame;
    PagingView *pageView;
    LevelSelectVC *selectLevelView;
}

@property (nonatomic, retain) IBOutlet UILabel *gameLabel;
@property (nonatomic, retain) IBOutlet UILabel *myMessage;
@property (nonatomic, retain) IBOutlet UIImageView *backgroundImageView;
@property (nonatomic, retain) IBOutlet UIViewController *menuView;
@property (nonatomic,retain) IBOutlet UIButton *newGame1;
@property (nonatomic,retain) IBOutlet UIButton *quickPlay;
@property (nonatomic,retain) IBOutlet UIButton *highScores;
@property (nonatomic,retain) IBOutlet UIButton *aboutGame;
@property (nonatomic,retain) IBOutlet UIButton *continueGame;


-(IBAction)startNewGame:(id)sender;

@end
