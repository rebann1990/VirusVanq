//
//  HighScores.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 10/3/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ModalViewDelegate;


@interface HighScores : UIViewController {
    id<ModalViewDelegate> delegate;
    
}

@property (nonatomic, retain) id<ModalViewDelegate> delegate;

-(IBAction)disappear;
@end
