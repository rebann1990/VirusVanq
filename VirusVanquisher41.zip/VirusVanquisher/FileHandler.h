//#import <NSMutableArray.h>
//#import <NSString.h>
#import <stdio.h>
#import <string.h>
#import <stdlib.h>

extern NSString* const SAVE_PATH;
extern NSString* const SCORE_DIR;
extern NSString* const SCORE_DELIMITER;

@interface FileHandler
{
}

+(int) SubmitScore: (int) score withFile: (NSString*) levelFile withDate: (NSString*) date;
+(NSMutableArray*) GetScores : (NSString*) levelFile;
+(BOOL) SaveLevel : (int) level;
+(int) LoadLevel;

@end
