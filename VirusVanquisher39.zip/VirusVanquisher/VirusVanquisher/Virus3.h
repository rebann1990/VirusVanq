//
//  Virus3.h
//  VirusVanquisher
//
//  Created by johannes alexander on 2/1/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus.h"

@interface Virus3 : Virus
{
    int counterTilDeath;
}

-(Virus *)initWithIndex:(int)button;
-(BOOL)checkDoubleTapKill;

@end
