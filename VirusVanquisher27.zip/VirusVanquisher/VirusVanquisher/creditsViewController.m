//
//  creditsViewController.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 11/18/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import "creditsViewController.h"

@implementation creditsViewController
@synthesize name4, name1, name2, name3, name5, name6, name7;
@synthesize titleLabel, stcLabel, devLabel;
@synthesize backButton;
@synthesize imageView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
  //  [imageView setAlpha:1.0];
    [backButton setAlpha:0.0];
    [name1 setAlpha:0.0];
    [name2 setAlpha:0.0];
    [name3 setAlpha:0.0];
    [name4 setAlpha:0.0];
    [name5 setAlpha:0.0];
    [name6 setAlpha:0.0];
    [name7 setAlpha:0.0];
    [titleLabel setAlpha:0.0];
    [stcLabel setAlpha:0.0];
    [devLabel setAlpha:0.0];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
  //  [imageView setAlpha:0.5];
    [backButton setAlpha:1.0];
    [name1 setAlpha:1.0];
    [name2 setAlpha:1.0];
    [name3 setAlpha:1.0];
    [name4 setAlpha:1.0];
    [name5 setAlpha:1.0];
    [name6 setAlpha:1.0];
    [name7 setAlpha:1.0];
    [titleLabel setAlpha:1.0];
    [stcLabel setAlpha:1.0];
    [devLabel setAlpha:1.0];
    [UIView commitAnimations];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)goBack
{
    [self performSelector:@selector(disappear) withObject:nil afterDelay:0.5];
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [backButton setAlpha:0.0];
    [name1 setAlpha:0.0];
    [name2 setAlpha:0.0];
    [name3 setAlpha:0.0];
    [name4 setAlpha:0.0];
    [name5 setAlpha:0.0];
    [name6 setAlpha:0.0];
    [name7 setAlpha:0.0];
    [titleLabel setAlpha:0.0];
    [stcLabel setAlpha:0.0];
    [devLabel setAlpha:0.0];
  //  [imageView setAlpha:1.0];
    [UIView commitAnimations];
}

-(void) disappear
{
    [self dismissModalViewControllerAnimated:NO];
}

-(void) dealloc
{
    [super dealloc];
    [titleLabel release];
    [name1 release];
    [name2 release];
    [name3 release];
    [name4 release];
    [name5 release];
    [name6 release];
    [name7 release];
    [stcLabel release];
    [devLabel release];
    [backButton release];
    [imageView release];
}

@end
