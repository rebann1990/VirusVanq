//
//  STCInfoView.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 12/22/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STCInfoView : UIViewController
{
    UITextView  *textView;
    int pageNum;
}

@property(nonatomic, retain) IBOutlet UITextView *textView;

- (id)initWithPageNumber:(int)page;

@end
