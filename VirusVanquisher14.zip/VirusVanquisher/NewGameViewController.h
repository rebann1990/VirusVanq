//
//  NewGameViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 10/3/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@protocol ModalViewDelegate;

@interface NewGameViewController : UIViewController {
    id<ModalViewDelegate> delegate;
    IBOutlet UIButton *button0;
    IBOutlet UIButton *button1;
    IBOutlet UIButton *button2;
    IBOutlet UIButton *button3;
    IBOutlet UIButton *button4;
    IBOutlet UIButton *button5;
    IBOutlet UIButton *button6;
    IBOutlet UIButton *button7;
    IBOutlet UIButton *button8;
    IBOutlet UILabel *scoreText;
    
    NSMutableArray *buttonArray;
    NSMutableArray *virusArray;
    NSMutableArray *timerArray;
    
    NSTimer *firstSpawnTimer;
    
    
}
@property (nonatomic, assign) id<ModalViewDelegate> delegate;
@property (nonatomic, retain) IBOutlet UIButton *button0;
@property (nonatomic, retain) IBOutlet UIButton *button1;
@property (nonatomic, retain) IBOutlet UIButton *button2;
@property (nonatomic, retain) IBOutlet UIButton *button3;
@property (nonatomic, retain) IBOutlet UIButton *button4;
@property (nonatomic, retain) IBOutlet UIButton *button5;
@property (nonatomic, retain) IBOutlet UIButton *button6;
@property (nonatomic, retain) IBOutlet UIButton *button7;
@property (nonatomic, retain) IBOutlet UIButton *button8;
@property (nonatomic, retain) IBOutlet UILabel *scoreText;

@property(nonatomic, retain) NSMutableArray *buttonArray;
@property(nonatomic, retain) NSMutableArray *virusArray;
@property(nonatomic, retain) NSMutableArray *timerArray;

@property(nonatomic, retain) NSTimer *firstSpawnTimer;



-(IBAction)disappear;
-(IBAction)tryToKill:(id)sender;
- (void)spawnEnemy:(NSTimer *)theTimer; 
-(int)findAvailableButton;

@end
