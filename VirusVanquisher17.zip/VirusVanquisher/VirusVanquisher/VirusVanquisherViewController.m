//
//  VirusVanquisherViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "VirusVanquisherViewController.h"
#import "AboutViewController.h"
#import "HighScores.h"
#import "NewGameViewController.h"
#import "PreGameViewController.h"

@implementation VirusVanquisherViewController

@synthesize menuView;
@synthesize newGame1;
@synthesize highScores;
@synthesize aboutGame;
@synthesize continueGame;
@synthesize quickPlay;
@synthesize backgroundImageView;
@synthesize gameLabel;
//DELEGATE USES THIS:
@synthesize myMessage;

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    //UIImage *background = [UIImage imageNamed: @"MenuBackground.png"];    
    //UIImageView *imageView = [[UIImageView alloc] initWithImage: background]; 
    //imageView.alpha = 1.0;
    //[self.view addSubview: imageView]; 
    //[self.view sendSubviewToBack:imageView];

    //[imageView release];
    [super viewDidLoad];
}

-(void)viewWillAppear:(BOOL)animated
{
    //While the UIElements fade from view...
    
    [backgroundImageView setAlpha:1.0];
    [newGame1 setAlpha:0.0];
    [continueGame setAlpha:0.0];
    [quickPlay setAlpha:0.0];
    [aboutGame setAlpha:0.0];
    [highScores setAlpha:0.0];
    [gameLabel setAlpha:0.0];
    
    //Fading Animation
    
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
    
    [backgroundImageView setAlpha:0.75];
    [gameLabel setAlpha:1.0];
    [newGame1 setAlpha:1.0];
    [continueGame setAlpha:1.0];
    [quickPlay setAlpha:1.0];
    [aboutGame setAlpha:1.0];
    [highScores setAlpha:1.0];
    [UIView commitAnimations];
    
    [super viewWillAppear:YES];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//DELEGATE USES THIS
- (void)didReceiveMessage:(NSString *)message {
	[myMessage setText:message];
}

- (void) dealloc {
    [super dealloc];
}
- (IBAction)startNewGame:(id)sender
{    
    if([sender isEqual:newGame1])
        [self performSelector:@selector(startLevel) withObject:nil afterDelay:0.5]; 
    else if([sender isEqual:continueGame])
        [self performSelector:@selector(startLevel) withObject:nil afterDelay:0.5];
    else if([sender isEqual:aboutGame])
        [self performSelector:@selector(viewAbout) withObject:nil afterDelay:0.5];
    else if([sender isEqual:quickPlay])
        [self performSelector:@selector(loadSelectLevel) withObject:nil afterDelay:0.5];
    else if([sender isEqual:highScores])
        [self performSelector:@selector(viewHighs) withObject:nil afterDelay:0.5];
    
    //While the UIElements fade from view...
    
    [backgroundImageView setAlpha:0.75];
    [newGame1 setAlpha:1.0];
    [continueGame setAlpha:1.0];
    [quickPlay setAlpha:1.0];
    [aboutGame setAlpha:1.0];
    [highScores setAlpha:1.0];
    [gameLabel setAlpha:1.0];

    
    //Fading Animation
    
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
    
    [backgroundImageView setAlpha:1.0];
    [gameLabel setAlpha:0.0];
    [newGame1 setAlpha:0.0];
    [continueGame setAlpha:0.0];
    [quickPlay setAlpha:0.0];
    [aboutGame setAlpha:0.0];
    [highScores setAlpha:0.0];
    [UIView commitAnimations];

}

-(void)viewAbout
{
	aboutView = [[[AboutViewController alloc] init] autorelease];
     aboutView.delegate = self;
     [self presentModalViewController:aboutView animated:NO];
}

-(void)viewHighs
{
	highView = [[[HighScores alloc] init] autorelease];
    highView.delegate = self;
    [self presentModalViewController:highView animated:NO];     
}

-(void) startLevel
{
    startGame= [[[PreGameViewController alloc] initWithlevelID: 1] autorelease];
    startGame.delegate = self;
    [self presentModalViewController:startGame animated:NO];    
}

- (void) loadSelectLevel
{
    selectLevelView= [[[LevelSelectVC alloc] init] autorelease];
    selectLevelView.delegate = self;
    [self presentModalViewController:selectLevelView animated:NO];
}


@end
