//
//  VirusVanquisherTests.m
//  VirusVanquisherTests
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "VirusVanquisherTests.h"

@implementation VirusVanquisherTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in VirusVanquisherTests");
}

@end
