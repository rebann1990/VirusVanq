//
//  HighScores.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 10/3/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ModalViewDelegate;


@interface HighScores : UIViewController {
    id<ModalViewDelegate> delegate;
    
    IBOutlet UIImageView *backgroundImageView;
    IBOutlet UISegmentedControl  *levelSegment;
    IBOutlet UITextView          *highScoreTV;
    IBOutlet UIButton            *mainMenuButton;
}

@property (nonatomic, retain) id<ModalViewDelegate> delegate;

@property (nonatomic, retain) IBOutlet UISegmentedControl *levelSegment;
@property (nonatomic, retain) IBOutlet UIButton *mainMenuButton;
@property (nonatomic, retain) IBOutlet UITextView *highScoreTV;

-(IBAction)showScores;
-(IBAction)disappear;
@end
