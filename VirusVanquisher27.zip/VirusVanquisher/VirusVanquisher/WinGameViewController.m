//
//  WinGameViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 11/3/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import "VirusVanquisherViewController.h"
#import "WinGameViewController.h"

@implementation WinGameViewController

@synthesize delegate;
@synthesize nextLevelViewButton;
@synthesize winText;
@synthesize mainMenuButton;
@synthesize winString;
int levelToGoTo = -1;

-(WinGameViewController *)initWithlevelID:(int)num
{    
	self = [super initWithNibName:@"WinGameViewController" bundle:nil];
	if(self) {
        levelToGoTo = num+1;
        winString = [NSString alloc];
        switch (num) {
            case 1:
                winString = @"Congratulations! You have managed to control the H1N1 flu outbreak by using the H1N1 vaccine and proper hand washing!";
                break;
            case 2:
                winString = @"Congratulations! You have managed to control Rabies outbreak by having your pet updated on their rabies vaccines!";
                break;
            case 3:
                winString = @"Congratulations! You have managed to control the HepB outbreak by using the HepB vaccine!";
                break;
            case 4:
                winString = @"Congratulations! You have managed to control the Chickenpox outbreak by using the Varicella vaccine!";
                break;
            case 5:
                winString = @"Congratulations! You have managed to control the German Measles outbreak by using the Rubella (MMR) vaccine!";
                break;
            case 6:
                winString = @"Congratulations! You have managed to control the Smallpox outbreak by using the Smallpox vaccine!";
                break;
            default:
                break;
        }
	}
	return self;	
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    winText.text = winString;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void) dealloc
{
    [super dealloc];
    [nextLevelViewButton release];
    [mainMenuButton release];
    [winText release];
    [winString release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(IBAction)startNextLevel:(id)sender
{
    //both mainMenu and StartNextLevel buttons use this method. Using senders to differentiate them.
    if([sender isEqual: mainMenuButton])
    {
        mainMenu = [[VirusVanquisherViewController alloc] init];
        [self presentModalViewController:mainMenu animated:NO];
    }
    else
    {
        startNextLevelControl = [[PreGameViewController alloc] initWithlevelID:levelToGoTo];
    
        [self presentModalViewController:startNextLevelControl animated:NO]; 
    }
}

@end
