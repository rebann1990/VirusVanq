//
//  NewGameViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 10/3/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "VirusVanquisherViewController.h"
#import "NewGameViewController.h"
#import "Virus.h"
#import "Virus1.h"
#import "Virus2.h"
#include <stdlib.h>


@implementation NewGameViewController
@synthesize delegate;
@synthesize bar1,bar2,bar3,bar4, multiplierNumberView;
@synthesize button0, button1, button2, button3, button4, button5, button6, button7, button8;
@synthesize virusArray , buttonArray, timerArray, spawnedVirusArray;
@synthesize quitButton, resumeButton, howToButton, pauseButton;
//delete backButton later
@synthesize pauseView;
@synthesize scoreText, enemiesLeftNumText, outbreakText;
//outbreakText to delete above
@synthesize firstSpawnTimer;
@synthesize levelNum;
int numOfVirusesAdded = 0;
int numOfButtonsUsed = 0;
int arrayOfButtons[9] ={0,0,0,0,0,0,0,0,0};
int timerIndex = 0;
int totalLevelScore = 0;
int spawnedVirusIndex = 0;
int currentLevelOn = 1;
int currentLevelOn0 = 0;
int numberOfVirusEnemiesLeft = 20;
int hitMultiplierNum = 1;
int counterThatIncrementsHitMultipler = 0;
bool isPlayingLevel = FALSE;
bool isPaused = FALSE;
bool pressedQuit = FALSE;
bool outbreakOn = FALSE;
bool winFlag = FALSE;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.button0 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button3 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button4 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button5 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button6 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button7 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.button8 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.pauseButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.howToButton  = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.quitButton  = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        self.resumeButton  = [UIButton buttonWithType:UIButtonTypeRoundedRect];
       
    }
    return self;
}

-(NewGameViewController *)initWithlevelID:(int)num
{    
	self = [super initWithNibName:@"NewGameViewController" bundle:nil];
	if(self) {
        currentLevelOn0 = num;
        switch (num) {
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            default:
                break;
        }
	}
	return self;	
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.view becomeFirstResponder];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated
{
    //If the game is not paused when being returned to,
    //Then reset everything
    //Else
    //Then the pause menu will be shown and no new timer will be created till unpaused
    if(isPaused == FALSE | pressedQuit == TRUE)
    {
        outbreakText.hidden = TRUE;
        pauseView.hidden = TRUE;
        resumeButton.hidden = TRUE;
        howToButton.hidden = TRUE;
        quitButton.hidden = TRUE;
        levelNum.hidden = TRUE;
        pauseButton.hidden = FALSE;
        
        bar1.hidden = TRUE;
        bar2.hidden = TRUE;
        bar3.hidden = TRUE;
        bar4.hidden = TRUE;
        multiplierNumberView.hidden = FALSE;
        
        isPlayingLevel = TRUE;
        outbreakOn = FALSE;
        
        currentLevelOn = currentLevelOn0;
        
        if(currentLevelOn == 1 || currentLevelOn == 2)
        {
            numberOfVirusEnemiesLeft = 20 + 9;
            if(currentLevelOn == 1)
                levelNum.text = @"Level 1";
            if(currentLevelOn == 2)
                levelNum.text = @"Level 2";
        }
        else if(currentLevelOn == 3)
        {
            numberOfVirusEnemiesLeft = 25 + 9;
        }
        else if(currentLevelOn == 4)
        {
            numberOfVirusEnemiesLeft = 30 + 9;
        }
        else if(currentLevelOn == 5)
        {
            numberOfVirusEnemiesLeft = 35 + 9;
        }
        else if(currentLevelOn == 6)
        {
            numberOfVirusEnemiesLeft = 60 + 9;
        }
        
        self.enemiesLeftNumText.text = [NSString stringWithFormat:@"%d",numberOfVirusEnemiesLeft-9];
        
        self.buttonArray = [NSMutableArray arrayWithCapacity:9];
        self.virusArray = [NSMutableArray arrayWithCapacity:numberOfVirusEnemiesLeft];
        self.spawnedVirusArray = [NSMutableArray arrayWithCapacity:numberOfVirusEnemiesLeft];
        self.timerArray = [NSMutableArray arrayWithCapacity:2];
        
        for(int i = 0; i < 9; ++i)
            arrayOfButtons[i]=0;
        
        if(currentLevelOn ==1)
        {
            for(int i = 0; i <numberOfVirusEnemiesLeft;i++)
            {
                int randomButtonToSpawn = arc4random() % 9;
                Virus1 *virus1 = [[Virus1 alloc] initWithIndex:randomButtonToSpawn];
                [self.virusArray insertObject:virus1 atIndex:i]; 
            }
        }
        else if(currentLevelOn == 2)
        {
            for(int i = 0; i <22;i++)
            {
                int randomButtonToSpawn = arc4random() % 9;
                Virus2 *virus2 = [[Virus2 alloc] initWithIndex:randomButtonToSpawn];
                [self.virusArray insertObject:virus2 atIndex:i]; 
            }
            for(int j = 22; j <numberOfVirusEnemiesLeft; ++j)
            {
                int randomButtonToSpawn = arc4random() % 9;
                Virus1 *virus1 = [[Virus1 alloc] initWithIndex:randomButtonToSpawn];
                [self.virusArray insertObject:virus1 atIndex:j];
            }
        }
        //here we need to add initilizating all other arrays for each level with different viruses. 
        
        [self.buttonArray insertObject:button0 atIndex:0];
        [self.buttonArray insertObject:button1 atIndex:1];
        [self.buttonArray insertObject:button2 atIndex:2];
        [self.buttonArray insertObject:button3 atIndex:3];
        [self.buttonArray insertObject:button4 atIndex:4];
        [self.buttonArray insertObject:button5 atIndex:5];
        [self.buttonArray insertObject:button6 atIndex:6];
        [self.buttonArray insertObject:button7 atIndex:7];
        [self.buttonArray insertObject:button8 atIndex:8];
        
        //Random .5 - 2 seconds
        float randomTime = (arc4random() % 2) +.5f;
        timerIndex = 0;
        numOfButtonsUsed = 0;
        numOfVirusesAdded = 0;
        totalLevelScore = 0;
        hitMultiplierNum = 1;
        counterThatIncrementsHitMultipler = 0;
        spawnedVirusIndex = 0;
        
        
        self.scoreText.text = @"0";
        
        firstSpawnTimer = [NSTimer scheduledTimerWithTimeInterval:randomTime
                                                           target:self selector:@selector(spawnEnemy:)
                                                         userInfo:nil repeats:YES];
        
        pressedQuit = FALSE;
    }
    else if(isPaused == TRUE)
    {
        pauseView.hidden = FALSE;
        resumeButton.hidden = FALSE;
        howToButton.hidden = FALSE;
        quitButton.hidden = FALSE;
        levelNum.hidden = FALSE;
        pauseButton.hidden = FALSE;
       
    }
    
    //Fill Spawned Virus Array with Null Objects
    
    for(int i = 0; i < 9; ++i)
    {
        [self.spawnedVirusArray addObject:[NSNull null]];
    }
    
    winFlag = FALSE;
    
    [super viewWillAppear:animated];
    
    [self becomeFirstResponder];
}

- (BOOL) canBecomeFirstResponder {
    return YES;
}

- (void) viewWillDisappear:(BOOL)animated
{
    //If paused, we want to return to the game's previous state, 
    //So nothing happens when it goes away
    
    if(isPaused == FALSE | pressedQuit == TRUE)
    {
        if([self.timerArray count]>=1)
        {
            for(int i = 0; i < [self.timerArray count];i++)
            {
                [[timerArray objectAtIndex:i] invalidate];
                [timerArray removeObjectAtIndex:i];
            }
        }
        if([self.virusArray count]>=1)
        {
            for(int i = 0; i < [self.virusArray count];i++)
            {
                [virusArray removeObjectAtIndex:i];
            }
        }
        if([self.spawnedVirusArray count]>=1)
        {
            for(int i = 0; i < [self.spawnedVirusArray count];i++)
            {
                [spawnedVirusArray removeObjectAtIndex:i];
            }
        }
        isPlayingLevel = FALSE;
        firstSpawnTimer = nil;
        self.virusArray = nil;
        self.buttonArray = nil;
        self.timerArray = nil;
        self.spawnedVirusArray = nil;
    }
    [super viewWillDisappear:YES];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void) dealloc
{
    [super dealloc];
    [button0 release];
    [button1 release];
    [button2 release];
    [button3 release];
    [button4 release];
    [button5 release];
    [button6 release];
    [button7 release];
    [button8 release];
    
    [enemiesLeftNumText release];
    [scoreText release];
    
    [pauseView release];
    [resumeButton release];
    [howToButton release];
    [quitButton release];
    [pauseButton release];
    
    
    [levelNum release];
    
    [outbreakText release];
    
    [buttonArray release];
    [virusArray release];
    [timerArray release];
    [spawnedVirusArray release];
}

-(IBAction) pauseGame
{
    //Invalidate the timer
    if(pauseView.hidden == TRUE)
    {
        isPaused = TRUE;
        pauseView.hidden = FALSE;
        howToButton.hidden = FALSE;
        resumeButton.hidden = FALSE;
        quitButton.hidden = FALSE;
        levelNum.hidden = FALSE;
        pauseButton.hidden = TRUE;
        
        
        if(timerIndex ==0)
        {
            [firstSpawnTimer invalidate];
        }
        
        if(timerIndex != 0)
        {
            [[timerArray objectAtIndex:timerIndex-1] invalidate];
            [timerArray removeObjectAtIndex:timerIndex-1];
        }
        
    }
    //if the game is paused and user goes to unpause... create a new timer
    else if(pauseView.hidden == FALSE)
    {
        isPaused = FALSE;
        pauseView.hidden = TRUE;
        howToButton.hidden = TRUE;
        resumeButton.hidden = TRUE;
        quitButton.hidden = TRUE;
        levelNum.hidden = TRUE;
        pauseButton.hidden = FALSE;
       
        
        float randomTime = (arc4random() % 3) +1;

        [timerArray addObject: [NSTimer scheduledTimerWithTimeInterval:randomTime
        target:self selector:@selector(spawnEnemy:)
        userInfo:nil repeats:YES]];
    }
}

-(IBAction)goToHow
{
    aboutPage = [[[PagingView alloc] initWithlevel:0] autorelease];
    [self presentModalViewController:aboutPage animated:NO];
}

-(IBAction)quitGame
{
    pressedQuit = TRUE;
    isPaused = FALSE;
    VirusVanquisherViewController *home = [[VirusVanquisherViewController alloc] init];
    [self presentModalViewController:home animated:NO];
}

-(IBAction)tryToKill:(id)sender
{
    bool kill = FALSE;
    
    int buttonTouched = -1;
    
    if([sender isEqual:button0]&&numOfButtonsUsed != 0)
     {
         buttonTouched = 0;
     }
    else if([sender isEqual:button1]&&numOfButtonsUsed != 0)
    {
        buttonTouched = 1; 
    }
    else if([sender isEqual:button2]&&numOfButtonsUsed != 0)
    {
        buttonTouched = 2;
    }
    else if([sender isEqual:button3]&&numOfButtonsUsed != 0)
    {
        buttonTouched = 3;
    }
    else if([sender isEqual:button4]&&numOfButtonsUsed != 0)
    {
        buttonTouched = 4;
    }
    else if([sender isEqual:button5]&&numOfButtonsUsed != 0)
    {
        buttonTouched = 5;
    }
    else if([sender isEqual:button6]&&numOfButtonsUsed != 0)
    {
        buttonTouched = 6;
    }    
    else if([sender isEqual:button7]&&numOfButtonsUsed != 0)
    {
        buttonTouched = 7;
    }
    else if([sender isEqual:button8]&&numOfButtonsUsed != 0)
    {
        buttonTouched = 8;
    }
    
    if(buttonTouched != -1)
    {
        if ([self.spawnedVirusArray objectAtIndex:buttonTouched]!=[NSNull null])
        {
            //do a level check right here to make sure it calls the right kill method
            kill = [[self.spawnedVirusArray objectAtIndex:buttonTouched] checkTapKill:buttonTouched];
            if(kill == true)
            {
                totalLevelScore+=hitMultiplierNum*[[self.spawnedVirusArray objectAtIndex:buttonTouched] getScore];
                self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                [[self.spawnedVirusArray objectAtIndex:buttonTouched] removeFromSuperview];
                arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:buttonTouched] getButtonSpawned]] = 0;
                [self.spawnedVirusArray replaceObjectAtIndex:buttonTouched withObject:[NSNull null]];
                numOfButtonsUsed--;
                numOfVirusesAdded--;
                numberOfVirusEnemiesLeft--; 
            }
        }
    }
    
    self.enemiesLeftNumText.text = [NSString stringWithFormat:@"%d",numberOfVirusEnemiesLeft-9];
    
    if((numberOfVirusEnemiesLeft - 9) == 10 && currentLevelOn == 1)
    {
        //outbreak occurs
        outbreakOn = TRUE;
        outbreakText.hidden = FALSE;
    }
    else if((numberOfVirusEnemiesLeft - 9) == 12 && currentLevelOn == 2)
    {
        outbreakOn = TRUE;
        outbreakText.hidden = FALSE;
    }
    
    [self calculateHitMultiplier: kill];
    [self checkWin];
}

- (void)spawnEnemy:(NSTimer *)theTimer 
{
    //if all buttons are full don't spawn an enemy.
    [self checkLose];
    if(numOfButtonsUsed != 9 && isPlayingLevel == TRUE)
    {
       
        int temp = [self.virusArray count];
        int randomVirusToPickFromArray;
        
        if(temp != 0)
        {
            //Random 0 - (temp-1)
            randomVirusToPickFromArray = 
            arc4random() % temp;
        }
        
        int availableButtonFound = [self findAvailableButton];
        int indexFlag = 0;
        
        if(arrayOfButtons[[[self.virusArray objectAtIndex: randomVirusToPickFromArray] getButtonSpawned]]==1)
        {
            //Available Button Found: If a virus was spawned already, spawn in new position
            
            indexFlag = 1;
            [[self.virusArray objectAtIndex: randomVirusToPickFromArray] setButtonSpawned: availableButtonFound];
        }
         
        //Spawn the Virus:
        
        [self.view insertSubview: [self.virusArray objectAtIndex: randomVirusToPickFromArray] atIndex: 1];
        
        arrayOfButtons[[[self.virusArray objectAtIndex: randomVirusToPickFromArray] getButtonSpawned]] = 1;
        
        //Long Thing: Use this index if AvailableButtonFound is not used
        
        int longThing = [[self.virusArray objectAtIndex:randomVirusToPickFromArray] getButtonSpawned];
        
        //Add Virus to the spawnedVirusArray so that it can be killed
        
        if(indexFlag == 1)
        {
            [self.spawnedVirusArray replaceObjectAtIndex:availableButtonFound withObject:[self.virusArray objectAtIndex:randomVirusToPickFromArray]];
        }
        else
        {
            [self.spawnedVirusArray replaceObjectAtIndex:longThing withObject:[self.virusArray objectAtIndex:randomVirusToPickFromArray]];
        }
        
        [self.virusArray removeObjectAtIndex:randomVirusToPickFromArray];
        
        numOfVirusesAdded++;
        numOfButtonsUsed++;
        
        
        //Timer Code, will create a timer and delete previous one.
        //Random 1 - 2 seconds for timerSpawnner
        float randomTime = (arc4random() % 2) +1;
        
        //outbreak code
        if((currentLevelOn == 1 || currentLevelOn == 2) && outbreakOn == TRUE)
        {
            //Random .5 - 1 seconds for timerSpawner
            randomTime = (arc4random() % 1) + .5;
            //NSTimer *outbreakTimer = [NSTimer scheduledTimerWithTimeInterval:4
            //                target:self selector:@selector(hideOutbreakText:)
            //                userInfo:nil repeats:NO];
            
        }
        
        if(timerIndex ==0)
        {
            [firstSpawnTimer invalidate];
        }
        
        [timerArray addObject: [NSTimer scheduledTimerWithTimeInterval:randomTime
        target:self selector:@selector(spawnEnemy:)
        userInfo:nil repeats:YES]];
        if(timerIndex != 0)
        {
            [[timerArray objectAtIndex:timerIndex-1] invalidate];
            [timerArray removeObjectAtIndex:timerIndex-1];
        }
        timerIndex = 1;
          
    }
}
-(int)findAvailableButton
{
    
    for(int i =0; i < 9 ;i++)
    {
        if(arrayOfButtons[i] == 0)
            return i;
                    
    }
    //will return -1 if the grid is full.
    return -1;
    
}
-(void)checkWin
{
    if(numberOfVirusEnemiesLeft == 9)
    {
        currentLevelOn++;
        winGameView= [[[WinGameViewController alloc] initWithlevelID:currentLevelOn-1] autorelease];
    
        winFlag = TRUE;
        
    [self presentModalViewController:winGameView animated:NO]; 
    }
}
-(void)checkLose
{
    if(numOfButtonsUsed == 9)
    {
        loseGameView= [[[LoseGameViewController alloc] initWithlevelID:currentLevelOn] autorelease];
        
        [self presentModalViewController:loseGameView animated:NO]; 
    }
}
- (void)hideOutbreakText:(NSTimer *)theTimer
{
    outbreakText.hidden = TRUE;
}
-(void)calculateHitMultiplier:(BOOL) wasKilled
{
    //enemy was killed increment multiplier counter
    if(wasKilled == TRUE)
    {
        if(hitMultiplierNum != 8)
        {
            counterThatIncrementsHitMultipler++;
            if(counterThatIncrementsHitMultipler == 5 & hitMultiplierNum == 1)
            {
                hitMultiplierNum++;
                counterThatIncrementsHitMultipler = 0;
            }
            else if(counterThatIncrementsHitMultipler == 5 & hitMultiplierNum == 2)
            {
                hitMultiplierNum=4;
                counterThatIncrementsHitMultipler = 0;
            }
            else if(counterThatIncrementsHitMultipler == 5 & hitMultiplierNum == 4)
            {
                hitMultiplierNum=6;
                counterThatIncrementsHitMultipler = 0;
            }
            else if(counterThatIncrementsHitMultipler == 5 & hitMultiplierNum == 6)
            {
                hitMultiplierNum=8;
                counterThatIncrementsHitMultipler = 0;
            }
        }
       
    }
    //enemy wasn't killed so reset multiplier
    else
    {
        counterThatIncrementsHitMultipler = 0;
        hitMultiplierNum = 1;
    }
    //update for the GUI for counter and hitmultiplier below
    if(counterThatIncrementsHitMultipler == 0)
    {
        bar1.hidden = TRUE; 
        bar2.hidden = TRUE; 
        bar3.hidden = TRUE; 
        bar4.hidden = TRUE; 
    }
    else if(counterThatIncrementsHitMultipler == 1)
    {
        bar1.hidden = FALSE; 
    }
    else if(counterThatIncrementsHitMultipler == 2)
    {
        bar2.hidden = FALSE; 
    }
    else if(counterThatIncrementsHitMultipler == 3)
    {
        bar3.hidden = FALSE; 
    }
    else if(counterThatIncrementsHitMultipler == 4)
    {
        bar4.hidden = FALSE; 
    }
    
    
    if(hitMultiplierNum == 1 )
    {
        multiplierNumberView.image = [UIImage imageNamed:@"x1.png"];;
    }
    else if(hitMultiplierNum == 2 )
    {
        multiplierNumberView.image = [UIImage imageNamed:@"x2.png"];;
    }
    else if(hitMultiplierNum == 4 )
    {
        multiplierNumberView.image = [UIImage imageNamed:@"x4.png"];;
    }
    else if(hitMultiplierNum == 6 )
    {
        multiplierNumberView.image = [UIImage imageNamed:@"x6.png"];;
    }
    else if(hitMultiplierNum == 8 )
    {
        multiplierNumberView.image = [UIImage imageNamed:@"x8.png"];;
    }
}

-(IBAction)playSound
{
    CFBundleRef mainBundle = CFBundleGetMainBundle();
    CFURLRef    soundFileURL;
    soundFileURL = CFBundleCopyResourceURL(mainBundle, (CFStringRef)@"Hit_Sound1", CFSTR ("wav"), NULL); 
    UInt32 soundID;
    AudioServicesCreateSystemSoundID(soundFileURL, &soundID);
    AudioServicesPlaySystemSound(soundID);
}

#pragma mark Motion Handling for Virus #2
- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    
    int killedInShake = 0;
    
    if(currentLevelOn == 2 && isPaused == FALSE)
    {
        for(int i = 0; i < 9; ++i)
        {
            bool kill = FALSE;
            //if button has enemy spawned on, KILL IT!
            if ([self.spawnedVirusArray objectAtIndex:i]!=[NSNull null])
            {
                //do a level check right here to make sure it calls the right kill method
                kill = [[self.spawnedVirusArray objectAtIndex:i] checkShakeKill];
                if(kill == true)
                {
                    totalLevelScore+=hitMultiplierNum*[[self.spawnedVirusArray objectAtIndex:i] getScore];
                    self.scoreText.text = [NSString stringWithFormat:@"%d",totalLevelScore];
                    [[self.spawnedVirusArray objectAtIndex:i] removeFromSuperview];
                    arrayOfButtons[[[self.spawnedVirusArray objectAtIndex:i] getButtonSpawned]] = 0;
                    [self.spawnedVirusArray replaceObjectAtIndex:i withObject:[NSNull null]];
                    numOfButtonsUsed--;
                    numOfVirusesAdded--;
                    numberOfVirusEnemiesLeft--; 
                    killedInShake+= 1;
                }
            }
            
            self.enemiesLeftNumText.text = [NSString stringWithFormat:@"%d",numberOfVirusEnemiesLeft-9];
            
            if((numberOfVirusEnemiesLeft - 9) == 12 && currentLevelOn >> 1)
            {
                outbreakOn = TRUE;
                outbreakText.hidden = FALSE;
            }
            
            if(killedInShake == 1 && kill == TRUE)
                [self calculateHitMultiplier: kill];
            [self checkWin];
            if(winFlag == TRUE)
                break;
        }
    }
}

@end
