//
//  AboutSTCView.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 11/16/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import "AboutSTCView.h"

@implementation AboutSTCView
@synthesize backButton, stcLabel, aboutText;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    [backButton setAlpha:0.0];
    [stcLabel setAlpha:0.0];
    [aboutText setAlpha:0.0];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [backButton setAlpha:1.0];
    [stcLabel setAlpha:1.0];
    [aboutText setAlpha:1.0];
    [UIView commitAnimations];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)goBack
{
    [self performSelector:@selector(disappear) withObject:nil afterDelay:0.5];
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [backButton setAlpha:0.0];
    [stcLabel setAlpha:0.0];
    [aboutText setAlpha:0.0];
    [UIView commitAnimations];
}

-(void) disappear
{
    [self dismissModalViewControllerAnimated:NO];
}

-(void) dealloc
{
    [super dealloc];
    [backButton release];
    [aboutText release];
    [stcLabel release];
}

@end
