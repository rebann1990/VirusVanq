//
//  Virus.h
//  VirusVanquisher
//
//  Created by johannes alexander on 10/24/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Virus : UIImageView
{
    int pointValue;
    int buttonThatSpawnedInNum;
}

-(Virus *)initWithImageWithButton:(UIImage *)image andIndex:(int)button;
-(int)getScore;
-(int)getButtonSpawned;
-(void)setButtonSpawned:(int) newButton;


@end
