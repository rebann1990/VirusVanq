//
//  AboutViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ModalViewDelegate;

@interface AboutViewController : UIViewController {
     id<ModalViewDelegate> delegate;
}

@property (nonatomic, assign) id<ModalViewDelegate> delegate;

-(IBAction)disappear;

@end
