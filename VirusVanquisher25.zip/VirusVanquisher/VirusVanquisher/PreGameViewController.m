//
//  PreGameViewController.m
//  VirusVanquisher
//
//  Created by johannes alexander on 10/16/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "PreGameViewController.h"
#import "PagingView.h"
#import <QuartzCore/QuartzCore.h>

@implementation PreGameViewController
@synthesize delegate;
@synthesize backgroundImageView;
@synthesize levelLabel;
@synthesize detailLabel;
@synthesize levelString;
@synthesize detailString;
@synthesize button1, button2, button3;

int level = -1;
-(PreGameViewController *)initWithlevelID:(int)num{
    
	self = [super initWithNibName:@"PreGameViewController" bundle:nil];
	if(self) {
        level = num;
        levelString = [NSString alloc];
        switch (num) {
            case 1:
                levelString =@"Level 1: \nInfluenza (H1N1)";
                detailString=@"Tap H1N1 to vanquish\n\nH1N1 flu (swine flu) is a respiratory disease caused by... (see Virus Bio for more)";
                break;
            case 2:
                levelString =@"Level 2: \nRabies";
                detailString=@"Shake device to vanquish Rabies\n\nThe Rabies virus infects the central nervous system, ultimately causing... (see Virus Bio for more)";
                break;
            case 3:
                levelString =@"Level 3: \nHepatitis B";
                detailString=@"Tap Hepatitis B twice to vanquish\n\nHepatitis B infection can be spread through contact with... (see Virus Bio for more)";
                break;
            case 4:
                levelString =@"Level 4: \nChicken Pox";
                detailString=@"Drag one cell onto another to vanquish\n\nChickenpox (Varicella) is a viral infection in which a person develops... (see Virus Bio for more)";
                break;
            case 5:
                levelString =@"Level 5: \nGerman Measles";
                detailString=@"Tap cell when dormant to vanquish\n\nGerman Measles (Rubella) is an infection in which there is a... (see Virus Bio for more)";
                break;
            case 6:
                levelString =@"Level 6: \nSmallpox";
                detailString=@"Align three Smallpox cells to vanquish\n\nSmallpox is caused by the... (see Virus Bio for more)";
                break;
            default:
                break;
        }
	}
	return self;	
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    
    levelLabel.text = levelString;
    detailLabel.text = detailString;
    
    //If the background has an alpha != the default,
    [backgroundImageView setAlpha:0.0];
    [button1 setAlpha:0.0];
    [button2 setAlpha:0.0];
    [button3 setAlpha:0.0];
    [detailLabel setAlpha:0.0];
    [levelLabel setAlpha:0.0];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    [backgroundImageView setAlpha:0.5];
    [button1 setAlpha:1.0];
    [button2 setAlpha:1.0];
    [button3 setAlpha:1.0];
    [detailLabel setAlpha:1.0];
    [levelLabel setAlpha:1.0];
    
    [UIView commitAnimations];

}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void) dealloc
{
    [super dealloc];
    //[startGame1 release];
    //[aboutPage release];
    
    [levelLabel release];
    [detailLabel release];
    [button1 release];
    [button2 release];
    [button3 release];
    [levelString release];
    [detailString release];
    [backgroundImageView release];
}


-(IBAction)startNewGame:(id)sender
{
    
    //Delay the method for opening the level half a second...
    
    if([sender isEqual:button3])
        [self performSelector:@selector(startLevel) withObject:nil afterDelay:0.5]; 
    else if([sender isEqual:button1])
        [self performSelector:@selector(goToMenu) withObject:nil afterDelay:0.5];
    else if([sender isEqual:button2])
        [self performSelector:@selector(goToAbout) withObject:nil afterDelay:0.5];
    
    //Fading Animation
    
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
    
    [backgroundImageView setAlpha:0.0];
    [button1 setAlpha:0.0];
    [button2 setAlpha:0.0];
    [button3 setAlpha:0.0];
    [detailLabel setAlpha:0.0];
    [levelLabel setAlpha:0.0];
    [UIView commitAnimations];

}

-(void) goToMenu
{
    [self dismissModalViewControllerAnimated:NO];
    
}

-(void) startLevel
{
    startGame1= [[[NewGameViewController alloc] init] autorelease];
    
    [self presentModalViewController:startGame1 animated:NO];    
}

-(void) goToAbout
{
    aboutPage = [[[PagingView alloc] initWithlevel:level] autorelease];
    [self presentModalViewController:aboutPage animated:NO];
}

@end
