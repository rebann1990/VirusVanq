//
//  VirusVanquisherAppDelegate.h
//  VirusVanquisher
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>

@class VirusVanquisherViewController;

@interface VirusVanquisherAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;


@property (nonatomic, retain) IBOutlet VirusVanquisherViewController *viewController;

@end
