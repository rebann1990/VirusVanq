//
//  Virus3.m
//  VirusVanquisher
//
//  Created by johannes alexander on 2/1/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus3.h"

@implementation Virus3
//
//  Virus1.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 1/26/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//
-(Virus *)initWithIndex:(int)button
{
    counterTilDeath = 2;
    self.type = @"Hepatitis B";
    self.image1 = [UIImage imageNamed:@"Hepatitis.png"];
    pointValue = 150;
    [super initWithIndex:button];
    return self;
}

-(BOOL)checkDoubleTapKill
{
    BOOL isKilled = false;
    if(counterTilDeath == 2)
    {
        counterTilDeath--;
        return false;
    }
    else if(counterTilDeath == 1)
    {
        isKilled = true;
    }
    
    return isKilled;
}

@end
