//
//  STCInfoView.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 12/22/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import "STCInfoView.h"

@implementation STCInfoView
@synthesize textView;

// Load the view nib and initialize the pageNumber ivar.
- (id)initWithPageNumber:(int)page {
    if (self = [super initWithNibName:@"STCInfoView" bundle:nil]) {
        pageNum = page;
    }
    return self;
}

- (void)dealloc {
    [textView release];
    [super dealloc];
}

// Set the label and background color when the view has finished loading.
- (void)viewDidLoad {
    if(pageNum == 0)
    {
        [textView setFont:[UIFont fontWithName:@"Helvetica" size:23]];
        textView.text = [NSString stringWithFormat:@"STC is widely recognized as a leading public health informatics company in the U.S. We play a key role in protecting the public from diseases. We leverage our more than twenty years of experience to develop solutions important to addressing and solving critical public health issues."];
    }
    else if(pageNum == 1)
    {
        [textView setFont:[UIFont fontWithName:@"Helvetica" size:19]];
        textView.text = [NSString stringWithFormat:@"The experience of STC combined with the partnership of our clients provides a critical source of public health information, resulting in: \n\n• 22,000,000 patients in STC\n  Immunization Registries (IRs)\n• 246,000,000 records in STC IRs\n• 17,000 providers utilizing STC IRs\n• 190,000 users of STC IRs\n• 700 electronic vendor links to STC\n  IRs\n• 93,000 HL7 messages sent per\n  day through one of STC’s state\n  registries."];
    }
    else if(pageNum == 2)
    {
        [textView setFont:[UIFont fontWithName:@"Helvetica" size:23]];
        textView.text = [NSString stringWithFormat:@"While we take great pride in delivering quality services, we are driven by the fact that we play a key role in protecting children and adults from disease, ultimately creating healthier populations.\n\nwww.stchome.com"];
    }
}

@end
