//
//  Virus5.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 2/7/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus5.h"

@implementation Virus5

-(Virus *)initWithIndex:(int)button
{
    self.type = @"German Measles";
    self.imageName = @"Rubella.png";
    self.imageNameNeg = @"Rubella_2.png";
    self.image1 = [UIImage imageNamed:@"Rubella.png"];
    pointValue = 150;
    
    self.description = @"History:\n\tGerman Measles (Rubella) is an infection in which there is a rash on the skin. It is spread through the air or by close contact. A person with rubella is contagious from 1 week before the rash begins, until 1 - 2 weeks after the rash disappears. Vaccination (MMR) is the best protection.\n\nTo vanquish the Rubella virus you have to tap it once when it is dormant. If you tap it when it's in a live state, then it will duplicate another plague to a random square on the screen.";
    
    [super initWithIndex:button];
    return self;
}

-(void)switchToNeg
{
    [self setImage:[UIImage imageNamed:imageNameNeg]];
}

-(void)setBack
{
    [self setImage:[UIImage imageNamed:imageName]];
}

@end
