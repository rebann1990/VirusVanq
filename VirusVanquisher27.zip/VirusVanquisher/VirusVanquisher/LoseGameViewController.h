//
//  LoseGameViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 11/14/11.
//  Copyright (c) 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
@class PreGameViewController;
@class VirusVanquisherViewController;

@protocol ModalViewDelegate;

@interface LoseGameViewController : UIViewController
{
    id<ModalViewDelegate>           delegate;
    PreGameViewController           *retryLevelControl;
    VirusVanquisherViewController   *mainMenu;
    UIButton                        *retryButton;
    UIButton                        *mainMenuButton;
    UILabel                         *loseText;
    
}

@property (nonatomic, assign) id<ModalViewDelegate> delegate;
@property (nonatomic,retain) IBOutlet UIButton *retryButton;
@property (nonatomic, retain) IBOutlet UIButton *mainMenuButton;
@property (nonatomic,retain) IBOutlet UILabel *loseText;

-(IBAction)retryLevel:(id)sender;

@end
