//
//  VirusVanquisherTests.h
//  VirusVanquisherTests
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface VirusVanquisherTests : SenTestCase

@end
