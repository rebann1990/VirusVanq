//
//  Virus1.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 1/26/12.
//  Copyright (c) 2012 EOIR. All rights reserved.
//

#import "Virus1.h"

@implementation Virus1

-(Virus *)initWithIndex:(int)button
{
    self.type = @"H1N1";
    self.image1 = [UIImage imageNamed:@"Virus1 standin.png"];
    [super initWithIndex:button];
    return self;
}

-(BOOL)checkTapKill:(int) buttonTapped
{
    BOOL isKilled = false;
    if([type isEqualToString:@"H1N1"])
    {
        if (buttonTapped == buttonThatSpawnedInNum)
        {
            isKilled = true;
        }
    }
    
    return isKilled;
}

@end
