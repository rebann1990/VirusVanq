//
//  AboutViewController.h
//  VirusVanquisher
//
//  Created by johannes alexander on 9/25/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ModalViewDelegate;

@interface AboutViewController : UIViewController <UIScrollViewDelegate> {
     id<ModalViewDelegate> delegate;
    
    UILabel *pageNumberLabel;
    int pageNumber;
    
    UILabel *numberTitle;
    UIImageView *numberImage;
    
	IBOutlet UIScrollView *scrollView;
    IBOutlet UIPageControl *pageControl;
    NSMutableArray *viewControllers;
}

@property (nonatomic, assign) id<ModalViewDelegate> delegate;
@property (nonatomic, retain) IBOutlet UIPageControl *pageControl;
@property (nonatomic, retain) IBOutlet UIScrollView *scrollView;
@property (nonatomic, retain) NSMutableArray *viewControllers;

-(IBAction)disappear;

@property (nonatomic, retain) IBOutlet UILabel *pageNumberLabel;

@property (nonatomic, retain) IBOutlet UILabel *numberTitle;
@property (nonatomic, retain) IBOutlet UIImageView *numberImage;

@end

