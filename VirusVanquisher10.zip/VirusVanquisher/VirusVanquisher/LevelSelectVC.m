//
//  LevelSelectVC.m
//  VirusVanquisher
//
//  Created by Ryan Ebann on 10/19/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import "LevelSelectVC.h"

@implementation LevelSelectVC
@synthesize button1, button2, button3, button4, button5, button6;
@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)loadLevel:(id)sender {
    if([sender isEqual:button1])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:1];
        [self presentModalViewController:startGame1 animated:NO];
    }
    else if([sender isEqual:button2])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:2];
        [self presentModalViewController:startGame1 animated:NO];
    }
    else if([sender isEqual:button3])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:3];
        [self presentModalViewController:startGame1 animated:NO];
    }
    else if([sender isEqual:button4])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:4];
        [self presentModalViewController:startGame1 animated:NO];
    }
    else if([sender isEqual:button5])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:5];
        [self presentModalViewController:startGame1 animated:NO];
    
    }
    else if([sender isEqual:button6])
    {
        startGame1= [[PreGameViewController alloc] initWithlevelID:6];
        [self presentModalViewController:startGame1 animated:NO];
    }
}

-(IBAction) disappear
{
    [self dismissModalViewControllerAnimated:YES];
}

@end
