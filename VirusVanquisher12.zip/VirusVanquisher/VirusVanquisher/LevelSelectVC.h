//
//  LevelSelectVC.h
//  VirusVanquisher
//
//  Created by Ryan Ebann on 10/19/11.
//  Copyright 2011 EOIR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PreGameViewController.h"
@protocol ModalViewDelegate;

@interface LevelSelectVC : UIViewController {
    
    id<ModalViewDelegate> delegate;
    
    PreGameViewController *startGame1;
    IBOutlet UIButton *button1;
    IBOutlet UIButton *button2;
    IBOutlet UIButton *button3;
    IBOutlet UIButton *button4;
    IBOutlet UIButton *button5;
    IBOutlet UIButton *button6;
}

@property (nonatomic, retain) id<ModalViewDelegate> delegate;

@property (nonatomic, retain) IBOutlet UIButton *button1;
@property (nonatomic, retain) IBOutlet UIButton *button2;
@property (nonatomic, retain) IBOutlet UIButton *button3;
@property (nonatomic, retain) IBOutlet UIButton *button4;
@property (nonatomic, retain) IBOutlet UIButton *button5;
@property (nonatomic, retain) IBOutlet UIButton *button6;

- (IBAction)loadLevel:(id)sender;
- (IBAction) disappear;

@end
